<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

header('Content-Type: application/json; charset=UTF-8');

$u = get_user();
if (!$u) {
    echo json_encode(['ok' => false]);
    exit;
}
try {
    echo json_encode([
        'ok'       => true,
        'msgs'     => conversation_unread_count((int) $u['id']),
        'notifs'   => notifications_unread_count((int) $u['id']),
        'ts'       => time(),
    ]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false]);
}
exit;