<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$me  = require_user();
$uid = (int) $me['id'];
$premium = is_premium($me);
$messagesSentToday = daily_message_count($uid);
$dailyMessageLimit = message_daily_limit($me);
$messageMaxChars = message_max_chars($me);
$noteReplyMode = isset($_GET['note_reply']) && $_GET['note_reply'] === '1';

$activeConv = isset($_GET['conv']) ? (int) $_GET['conv'] : 0;

/* New conversation via ?to=ID (message button on profiles/services). */
$toId = isset($_GET['to']) ? (int) $_GET['to'] : 0;
if ($toId > 0 && $toId !== $uid) {
    $target = row('SELECT id, full_name, premium_until, account_status FROM users WHERE id = ?', [$toId]);
    if ($target && $target['account_status'] === 'verified') {
        $activeConv = start_conversation(min($uid, $toId), max($uid, $toId));
    }
}

$errors  = [];
$prefill = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'update_presence') {
        $profileStatus = (string) ($_POST['profile_status'] ?? 'online');
        $profileNote = trim((string) ($_POST['profile_note'] ?? ''));
        $noteTheme = (string) ($_POST['profile_note_theme'] ?? 'indigo');
        if (!array_key_exists($profileStatus, profile_statuses())) {
            $errors[] = 'Choose a valid presence status.';
        } elseif (mb_strlen($profileNote) > 160) {
            $errors[] = 'Keep your note under 160 characters.';
        } else {
            if (!array_key_exists($noteTheme, profile_note_themes()) || !$premium) {
                $noteTheme = 'indigo';
            }

            q('UPDATE users SET profile_status = ?, profile_note = ?, profile_note_theme = ? WHERE id = ?', [
                $profileStatus,
                $profileNote !== '' ? $profileNote : null,
                $noteTheme,
                $uid,
            ]);
            flash('ok', 'Your message status and note were updated.');
            redirect('messages.php' . ($activeConv > 0 ? '?conv=' . $activeConv : ''));
        }
    }

    if ($action === 'update_chat_theme') {
        $chatTheme = (string) ($_POST['chat_theme'] ?? 'indigo');
        if (!$premium) {
            flash('warn', 'Chat themes are a Nerasky Pro feature. Upgrade to unlock custom message colors.');
        } elseif (!array_key_exists($chatTheme, chat_themes())) {
            flash('bad', 'Choose a valid chat theme.');
        } else {
            q('UPDATE users SET chat_theme = ? WHERE id = ?', [$chatTheme, $uid]);
            flash('ok', 'Chat theme updated.');
        }
        redirect('messages.php' . ($activeConv > 0 ? '?conv=' . $activeConv : ''));
    }

    if ($action === 'send' && $activeConv > 0) {
        $body = trim((string) ($_POST['body'] ?? ''));
        $hasFile = isset($_FILES['attachment']) && (int) ($_FILES['attachment']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
        $isNoteReply = (string) ($_POST['note_reply'] ?? '') === '1';
        $noteRepliesToday = (int) (db()->query("SELECT COUNT(*) FROM conversation_messages WHERE sender_id = " . $uid . " AND body LIKE 'Reply to note:%' AND created_at >= CURDATE()")->fetchColumn() ?: 0);
        if ($body === '' && !$hasFile) {
            $errors[] = 'Message can\'t be empty.';
        } elseif ($isNoteReply && !$premium && $noteRepliesToday >= FREE_NOTE_REPLIES) {
            $errors[] = 'Free accounts can send up to ' . FREE_NOTE_REPLIES . ' note replies per day. Upgrade to Pro for unlimited note replies.';
        } elseif (mb_strlen($body) > $messageMaxChars) {
            $errors[] = 'Your messages can be up to ' . $messageMaxChars . ' characters on your current plan.';
        } elseif ($messagesSentToday >= $dailyMessageLimit) {
            $errors[] = 'You have reached today\'s ' . $dailyMessageLimit . '-message limit. Try again tomorrow or upgrade to Pro for ' . PREMIUM_DAILY_MESSAGES . ' messages per day.';
        } else {
            $conv = row('SELECT * FROM conversations WHERE id = ? AND (user1_id = ? OR user2_id = ?)', [$activeConv, $uid, $uid]);
            if ($conv) {
                $body = $isNoteReply ? 'Reply to note: ' . $body : $body;
                if ($hasFile) {
                    [$uploaded, $attachment] = conversation_attachment_upload($_FILES['attachment']);
                    if (!$uploaded) {
                        $errors[] = (string) $attachment;
                    } else {
                        send_conversation_attachment_message($activeConv, $uid, $body, $attachment);
                    }
                } else {
                    send_conversation_message($activeConv, $uid, $body);
                }
                if ($errors === []) {
                redirect('messages.php?conv=' . $activeConv . '&sent=1#msg-thread-box');
                }
            } else {
                $errors[] = 'That conversation isn\'t yours.';
            }
        }

    }

    if (($action === 'archive' || $action === 'delete') && $activeConv > 0) {
        $conv = row('SELECT * FROM conversations WHERE id = ? AND (user1_id = ? OR user2_id = ?)', [$activeConv, $uid, $uid]);
        if ($conv) {
            $column = (int) $conv['user1_id'] === $uid ? 'archived_user1' : 'archived_user2';
            q('UPDATE conversations SET ' . $column . ' = 1 WHERE id = ?', [$activeConv]);
            flash('ok', $action === 'archive' ? 'Conversation archived.' : 'Conversation removed from your inbox.');
        }
        redirect('messages.php');
    }

    if ($action === 'compose') {
        $to   = (int) ($_POST['to'] ?? 0);
        $body = trim((string) ($_POST['body'] ?? ''));
        if ($to <= 0 || $to === $uid) {
            $errors[] = 'Pick someone to message.';
        } else {
            $targetUser = row('SELECT id, full_name, account_status FROM users WHERE id = ?', [$to]);
            if (!$targetUser) {
                $errors[] = 'That student doesn\'t exist.';
            } elseif ($targetUser['account_status'] !== 'verified') {
                $errors[] = 'That account isn\'t verified yet — you can\'t message them yet.';
            } elseif ($body === '') {
                $errors[] = 'Write a short first message so they know who you are.';
            } elseif (mb_strlen($body) > $messageMaxChars) {
                $errors[] = 'Your messages can be up to ' . $messageMaxChars . ' characters on your current plan.';
            } elseif ($messagesSentToday >= $dailyMessageLimit) {
                $errors[] = 'You have reached today\'s ' . $dailyMessageLimit . '-message limit. Try again tomorrow or upgrade to Pro for ' . PREMIUM_DAILY_MESSAGES . ' messages per day.';
            } else {
                $cid = start_conversation(min($uid, $to), max($uid, $to));
                send_conversation_message($cid, $uid, $body);
                flash('ok', 'Message sent!');
                redirect('messages.php?conv=' . $cid);
            }
        }
        $prefill = $body;
    }
}
/* ---- inbox list ---- */
$convs = rows(
    'SELECT c.id, c.created_at, c.last_message_at,
            CASE WHEN c.user1_id = ? THEN c.user2_id ELSE c.user1_id END AS other_id,
            u.id AS user_id, u.email, u.full_name, u.premium_until, u.account_status, u.profile_frame, u.profile_accent, u.profile_status, u.profile_note, u.profile_note_theme,
            (SELECT cm.body FROM conversation_messages cm WHERE cm.conversation_id = c.id ORDER BY cm.id DESC LIMIT 1) AS last_body,
            (SELECT cm.created_at FROM conversation_messages cm WHERE cm.conversation_id = c.id ORDER BY cm.id DESC LIMIT 1) AS last_at,
            (SELECT COUNT(*) FROM conversation_messages nr WHERE nr.conversation_id = c.id AND nr.body LIKE \'Reply to note:%\') AS note_reply_count
     FROM conversations c
     JOIN users u ON u.id = (CASE WHEN c.user1_id = ? THEN c.user2_id ELSE c.user1_id END)
     WHERE (c.user1_id = ? AND c.archived_user1 = 0) OR (c.user2_id = ? AND c.archived_user2 = 0)
     ORDER BY COALESCE(last_message_at, c.created_at) DESC LIMIT 60',
    [$uid, $uid, $uid, $uid]
);

$unreadByConv = [];
foreach (rows(
    'SELECT c.id, COUNT(*) AS n
     FROM conversation_messages cm
     JOIN conversations c ON c.id = cm.conversation_id
     WHERE cm.is_read = 0 AND cm.sender_id <> ?
       AND (c.user1_id = ? OR c.user2_id = ?)
     GROUP BY c.id',
    [$uid, $uid, $uid]
) as $r) {
    $unreadByConv[(int) $r['id']] = (int) $r['n'];
}
$totalUnreadMsgs = array_sum($unreadByConv);

/* ---- active thread ---- */
$thread = null;
if ($activeConv > 0) {
    $conv = row('SELECT * FROM conversations WHERE id = ? AND (user1_id = ? OR user2_id = ?)', [$activeConv, $uid, $uid]);
    if ($conv) {
        $otherId = (int) $conv['user1_id'] === $uid ? (int) $conv['user2_id'] : (int) $conv['user1_id'];
        $other   = row('SELECT id, email, full_name, premium_until, account_status, profile_frame, profile_accent, profile_status, profile_note, profile_note_theme FROM users WHERE id = ?', [$otherId]);
        $msgs    = rows('SELECT cm.*, u.id AS user_id, u.email, u.full_name, u.account_status, u.premium_until, u.chat_theme, u.profile_frame, u.profile_accent, u.profile_status FROM conversation_messages cm JOIN users u ON u.id = cm.sender_id WHERE cm.conversation_id = ? ORDER BY cm.id ASC', [$activeConv]);
        q('UPDATE conversation_messages SET is_read = 1 WHERE conversation_id = ? AND sender_id <> ? AND is_read = 0', [$activeConv, $uid]);
        $thread = ['conv' => $conv, 'other' => $other, 'msgs' => $msgs];
    }
}

/* recently active verified students to message (compose picker) */
$sellers = rows(
    'SELECT DISTINCT u.id, u.full_name, u.premium_until, u.account_status, u.profile_status, u.profile_note, u.profile_note_theme
     FROM users u WHERE u.account_status = "verified" AND u.id <> ? ORDER BY u.full_name LIMIT 40',
    [$uid]
);

/* fragment endpoint for the thread polling */
if (isset($_GET['fragment']) && $_GET['fragment'] === 'thread') {
    header('Content-Type: text/html; charset=UTF-8');
    $conv = row('SELECT * FROM conversations WHERE id = ? AND (user1_id = ? OR user2_id = ?)', [$activeConv, $uid, $uid]);
    $msgs = [];
    if ($conv) {
        $msgs = rows('SELECT cm.*, u.id AS user_id, u.email, u.full_name, u.account_status, u.premium_until, u.chat_theme, u.profile_frame, u.profile_accent, u.profile_status FROM conversation_messages cm JOIN users u ON u.id = cm.sender_id WHERE cm.conversation_id = ? ORDER BY cm.id ASC', [$activeConv]);
        q('UPDATE conversation_messages SET is_read = 1 WHERE conversation_id = ? AND sender_id <> ? AND is_read = 0', [$activeConv, $uid]);
    }
    echo conv_msgs_html($msgs, $uid);
    exit;
}

$pageTitle  = 'Messages';
$currentNav = 'messages';
$bodyClass  = $thread ? 'page-messages-thread' : 'page-messages';
require __DIR__ . '/includes/header.php';
?>

<?php
function conv_msgs_html(array $msgs, int $myId): string
{
    if ($msgs === []) {
        return '<div class="empty-state" style="padding:2rem"><div class="es-ic">' . ui_icon('chat') . '</div><b>No messages yet</b><p class="muted" style="margin:0">Say the first hello — start with what you need and your deadline.</p></div>';
    }
    $out = '';
    $lastDay = null;
    foreach ($msgs as $m) {
        $day = date('Y-m-d', strtotime((string) $m['created_at']));
        if ($day !== $lastDay) {
            $out .= '<div class="msg-day">' . date('M j', strtotime((string) $m['created_at'])) . '</div>';
            $lastDay = $day;
        }
        $mine = (int) $m['sender_id'] === $myId;
        $attachment = '';
        if (!empty($m['attachment_path'])) {
            $url = asset_url((string) $m['attachment_path']);
            $name = e((string) ($m['attachment_name'] ?: 'Attachment'));
            $isImage = strpos((string) ($m['attachment_mime'] ?? ''), 'image/') === 0;
            $attachment = $isImage
                ? '<a class="msg-attachment-image" href="' . e($url) . '" download="' . $name . '" target="_blank" rel="noopener"><img src="' . e($url) . '" alt="' . $name . '"></a>'
                : '<a class="msg-attachment" href="' . e($url) . '" download="' . $name . '" rel="noopener">📎 ' . $name . ' <small>Download</small></a>';
        }
        $out .= '<div class="msg ' . ($mine ? 'sent' : '') . '">'
            . ($mine ? '' : avatar_of($m, 32))
            . '<div><div class="msg-bub ' . e(chat_theme_class($m)) . '">' . ($m['body'] !== '' ? '<p class="msg-body">' . e($m['body']) . '</p>' : '') . $attachment . '</div>'
            . '<div class="msg-meta">' . e(explode(' ', $m['full_name'])[0]) . ' · ' . date('g:i A', strtotime((string) $m['created_at'])) . '</div></div></div>';
    }
    return $out;
}
?>
<section class="page-head messages-page-head<?= $thread ? ' has-message-thread' : '' ?>" style="padding-bottom:.6rem">
  <div class="container flex-between">
    <div>
      <span class="eyebrow">Inbox</span>
      <h1>Messages</h1>
      <p class="muted">Student-to-student, always inside Nerasky.</p>
    </div>
    <button class="btn btn-primary" id="composeBtn" type="button">+ New message</button>
  </div>
</section>

<?php foreach ($errors as $err): ?>
  <div class="container"><div class="banner banner-bad mb-2"><span class="b-ic">✕</span><span><?= e($err) ?></span></div></div>
<?php endforeach; ?>

<section class="section-tight messages-presence-section<?= $thread ? ' has-message-thread' : '' ?>" style="padding-top:1rem">
  <div class="container">
    <div class="message-presence-card card">
      <div class="message-presence-copy">
        <span class="eyebrow">Your message presence</span>
        <b><?= profile_status_badge($me) ?> Let people know when you’re available</b>
        <small class="muted">This status and note appear in your conversations and profile.</small>
        <?php if (trim((string) ($me['profile_note'] ?? '')) !== ''): ?>        <span class="message-current-note <?= e(profile_note_theme_class($me)) ?>"><?= ui_icon('message', 12) ?> <?= e($me['profile_note']) ?></span><?php else: ?><span class="message-current-note muted">No note yet</span><?php endif; ?>
      </div>
      <button class="btn btn-outline btn-sm" type="button" id="presenceToggle" aria-expanded="false" aria-controls="presencePanel chatThemePanel" onclick="var p=document.getElementById('presencePanel'),t=document.getElementById('chatThemePanel');var open=p.hidden;p.hidden=!open;t.hidden=!open;this.setAttribute('aria-expanded',open?'true':'false');this.innerHTML=open?'Hide customize':'Customize';"><?= ui_icon('settings', 14) ?> Customize</button>
      <form method="post" class="message-presence-form" id="presencePanel" hidden>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="update_presence">
        <select class="input" name="profile_status" aria-label="Message presence status">
          <?php foreach (profile_statuses() as $statusKey => $status): ?>
            <option value="<?= e($statusKey) ?>" <?= (string) ($me['profile_status'] ?? 'online') === $statusKey ? 'selected' : '' ?>><?= e($status['label']) ?></option>
          <?php endforeach; ?>
        </select>
        <input class="input" name="profile_note" maxlength="160" value="<?= e((string) ($me['profile_note'] ?? '')) ?>" placeholder="Add a note">
        <select class="input" name="profile_note_theme" aria-label="Note appearance" <?= !$premium ? 'disabled' : '' ?>><?php foreach (profile_note_themes() as $themeKey => $theme): ?><option value="<?= e($themeKey) ?>" <?= profile_note_theme_key($me) === $themeKey ? 'selected' : '' ?>><?= e($theme['label']) ?><?= !$premium && $themeKey !== 'indigo' ? ' ★ Pro' : '' ?></option><?php endforeach; ?></select>
        <button class="btn btn-primary btn-sm" type="submit"><?= ui_icon('check', 14) ?> Save</button>
      </form>
      <form method="post" class="message-theme-form" id="chatThemePanel" hidden>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="update_chat_theme">
        <label><span>Chat theme <?php if (!$premium): ?><small class="pro-lock">★ Pro</small><?php endif; ?></span></label>
        <div class="chat-theme-choices" role="radiogroup" aria-label="Chat theme choices">
          <?php foreach (chat_themes() as $themeKey => $theme): ?>
            <label class="chat-theme-choice" style="--theme-preview:<?= e($theme['gradient']) ?>">
              <input type="radio" name="chat_theme" value="<?= e($themeKey) ?>" <?= chat_theme_key($me) === $themeKey ? 'checked' : '' ?> data-pro="<?= $premium ? '1' : '0' ?>" onchange="if(this.value !== 'indigo' && this.dataset.pro !== '1'){document.getElementById('chatThemeNotice').textContent='Custom colors are a Nerasky Pro feature. Upgrade to unlock this theme.';document.querySelector('input[name=chat_theme][value=indigo]').checked=true;}">
              <span class="chat-theme-swatch" aria-hidden="true"></span>
              <span><b><?= e($theme['label']) ?></b><small><?= e($theme['description']) ?></small></span>
              <?php if (!$premium && $themeKey !== 'indigo'): ?><em>★ Pro</em><?php endif; ?>
            </label>
          <?php endforeach; ?>
        </div>
        <button class="btn btn-outline btn-sm" type="submit"><?= ui_icon('palette', 14) ?> Save theme</button>
        <small id="chatThemeNotice" class="muted"><?= $premium ? 'Your sent bubbles use this theme.' : 'Custom colors require Nerasky Pro.' ?></small>
      </form>
    </div>
    <div class="msg-layout <?= $thread ? 'has-active-thread mobile-chat-open' : 'mobile-chat-hidden' ?>" id="messagesLayout">
      <!-- inbox list -->
      <div class="msg-side card">
        <?php if (count($convs) > 0): ?>
          <div class="msg-quick-people" aria-label="Quick chat contacts">
            <button class="msg-quick-person msg-quick-own" type="button" data-open-presence aria-label="Edit your message note">
              <span class="msg-quick-avatar"><?= avatar_of($me, 54) ?></span>
              <span class="msg-quick-name">Your note</span>
              <span class="msg-quick-note <?= e(profile_note_theme_class($me)) ?>"><?= trim((string) ($me['profile_note'] ?? '')) !== '' ? e(mb_strimwidth((string) $me['profile_note'], 0, 22, '…')) : 'Add a note' ?></span>
            </button>
            <?php foreach (array_slice($convs, 0, 12) as $quick): ?>
              <a class="msg-quick-person<?= (int) $quick['id'] === $activeConv ? ' active' : '' ?>" data-conversation-link href="<?= e(base_url('messages.php?conv=' . (int) $quick['id'])) ?>" aria-label="Chat with <?= e($quick['full_name']) ?>">
                <span class="msg-quick-avatar"><?= avatar_of($quick, 54) ?></span>
                <span class="msg-quick-name"><?= e(mb_strimwidth((string) $quick['full_name'], 0, 12, '…')) ?></span>
                <?php if (trim((string) ($quick['profile_note'] ?? '')) !== ''): ?>                                <span class="msg-quick-note <?= e(profile_note_theme_class($quick)) ?>" data-note="<?= e((string) $quick['profile_note']) ?>" data-note-name="<?= e($quick['full_name']) ?>" data-note-replies="<?= (int) ($quick['note_reply_count'] ?? 0) ?>" data-note-reply-url="<?= e(base_url('messages.php?conv=' . (int) $quick['id'] . '&note_reply=1')) ?>"><?= e(mb_strimwidth((string) $quick['profile_note'], 0, 22, '…')) ?></span><?php endif; ?>
              </a>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <div class="msg-side-head">
          <span class="fs-sm" style="font-weight:700;color:var(--ink-900)">Conversations</span>
          <?php if ($totalUnreadMsgs > 0): ?><span class="pill pill-brand"><span class="dot"></span><?= $totalUnreadMsgs ?> new</span><?php endif; ?>
          <?php if ($thread): ?><button class="btn btn-outline btn-sm mobile-see-chat" type="button" data-chat-action="show"><?= ui_icon('message', 14) ?> See chat</button><?php endif; ?>
          <input class="input msg-search" type="search" placeholder="Search conversations" aria-label="Search conversations" data-message-search>
        </div>
        <div class="msg-list">
          <?php if (count($convs) > 0): ?>
            <?php foreach ($convs as $c):
              $uu = (int) ($unreadByConv[(int) $c['id']] ?? 0);
              $isActive = (int) $c['id'] === $activeConv;
            ?>
              <a class="msg-item<?= $isActive ? ' active' : '' ?>" data-conversation-link data-message-search-item="<?= e(strtolower($c['full_name'] . ' ' . (string) ($c['last_body'] ?? ''))) ?>" href="<?= e(base_url('messages.php?conv=' . (int) $c['id'])) ?>">
                <?= avatar_of($c, 40) ?>
                <div class="msg-item-main">
                  <div class="flex-between" style="gap:.4rem">
                    <span class="msg-item-identity"><b><?= e($c['full_name']) ?></b><?= profile_status_badge($c, false) ?></span>
                    <small class="msg-item-time"><?= time_ago((string) ($c['last_at'] ?? $c['last_message_at'] ?? $c['created_at'])) ?></small>
                  </div>
                  <div class="msg-item-prev">
                    <span<?= $uu > 0 ? ' class="unread"' : '' ?>><?= e(mb_strimwidth((string) $c['last_body'], 0, 46, '…')) ?></span>
                    <?php if ($uu > 0): ?><em><?= $uu ?></em><?php endif; ?>
                  </div>
                  <?php if (trim((string) ($c['profile_note'] ?? '')) !== ''): ?><small class="conversation-note <?= e(profile_note_theme_class($c)) ?>" data-note="<?= e((string) $c['profile_note']) ?>" data-note-name="<?= e($c['full_name']) ?>" data-note-replies="<?= (int) ($c['note_reply_count'] ?? 0) ?>" data-note-reply-url="<?= e(base_url('messages.php?conv=' . (int) $c['id'] . '&note_reply=1')) ?>" title="<?= e($c['profile_note']) ?>"><span class="conversation-note-label"><?= ui_icon('message', 12) ?> Note</span><span><?= e($c['profile_note']) ?></span></small><?php endif; ?>
                </div>
              </a>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="empty-state" style="padding:2rem 1rem">
              <div class="es-ic"><?= ui_icon('message') ?></div>
              <b>No conversations yet</b>
              <p class="muted">Message a seller directly from any service page or profile.</p>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- active thread -->
      <div class="msg-thread card">
        <?php if ($thread): $other = $thread['other']; ?>
          <?php if (count($convs) > 1): ?>
          <div class="msg-thread-quick mobile-only" aria-label="Switch conversation">
            <?php foreach (array_slice($convs, 0, 12) as $quick): ?>
              <a class="tq-person<?= (int) $quick['id'] === $activeConv ? ' active' : '' ?>" data-conversation-link href="<?= e(base_url('messages.php?conv=' . (int) $quick['id'])) ?>" aria-label="Chat with <?= e($quick['full_name']) ?>">
                <span class="tq-av"><?= avatar_of($quick, 38) ?></span>
                <span class="tq-name"><?= e(mb_strimwidth((string) $quick['full_name'], 0, 10, '…')) ?></span>
              </a>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
          <div class="msg-thread-head">
            <button class="btn btn-outline btn-sm mobile-hide-chat" type="button" data-chat-action="hide" aria-label="Back to conversations" title="Back to conversations"><?= ui_icon('arrow-left', 16) ?><span>Back</span></button>
            <div class="flex gap-2">
              <?= avatar_of($other, 38) ?>
              <div>
                <div class="msg-thread-identity">
                  <b><?= e($other['full_name']) ?></b><?= profile_status_badge($other) ?>
                  <?php if (is_premium($other)): ?><?= premium_badge() ?><?php endif; ?>
                </div>
                <span class="muted" style="font-size:var(--fs-xs)"><?= $other['account_status'] === 'verified' ? 'Verified student' : 'Pending verification' ?> · <span id="typingIndicator" aria-live="polite"><?= e(profile_statuses()[(string) ($other['profile_status'] ?? 'offline')]['label'] ?? 'Offline') ?></span></span>
                <?php if (trim((string) ($other['profile_note'] ?? '')) !== ''): ?><small class="conversation-note conversation-note-thread <?= e(profile_note_theme_class($other)) ?>" data-note="<?= e((string) $other['profile_note']) ?>" data-note-name="<?= e($other['full_name']) ?>" data-note-replies="0" data-note-reply-url="<?= e(base_url('messages.php?conv=' . $activeConv . '&note_reply=1')) ?>" title="<?= e($other['profile_note']) ?>"><span class="conversation-note-label"><?= ui_icon('message', 13) ?> Note</span><span><?= e($other['profile_note']) ?></span></small><?php endif; ?>
              </div>
            </div>
            <div class="flex gap-1"><a class="btn btn-outline btn-sm" href="<?= e(base_url('profile.php?id=' . (int) $other['id'])) ?>">View profile</a>
              <form method="post" onsubmit="return confirm('Archive this conversation?')"><?= csrf_field() ?><input type="hidden" name="action" value="archive"><input type="hidden" name="conv" value="<?= $activeConv ?>"><button class="btn btn-outline btn-sm" type="submit">Archive</button></form>
              <form method="post" onsubmit="return confirm('Delete this conversation from your inbox?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="conv" value="<?= $activeConv ?>"><button class="btn btn-outline btn-sm" type="submit" aria-label="Delete conversation">Delete</button></form>
            </div>
          </div>

          <div class="chat-box" id="msg-thread-box" data-conv="<?= (int) $activeConv ?>" data-conv-url="<?= e(base_url('messages.php?conv=' . $activeConv)) ?>">
            <?= conv_msgs_html($thread['msgs'], $uid) ?>
          </div>
          <button class="chat-jump-bottom hidden" type="button" data-chat-jump><?= ui_icon('arrow-down', 14) ?> Latest messages</button>

          <form method="post" enctype="multipart/form-data" action="<?= e(base_url('messages.php?conv=' . $activeConv)) ?>" class="msg-thread-form" id="messageSendForm">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="send">
            <input type="hidden" name="note_reply" value="<?= $noteReplyMode ? '1' : '0' ?>">
            <div class="message-compose">
              <div class="message-templates" aria-label="Suggested messages">
                <button type="button" class="chip" data-message-template="What is your delivery time?">Delivery time?</button>
                <button type="button" class="chip" data-message-template="Is this still available?">Still available?</button>
              </div>
              <textarea class="input" name="body" rows="2" maxlength="<?= $messageMaxChars ?>" placeholder="<?= $noteReplyMode ? 'Reply to their note…' : 'Write a message…' ?>"></textarea>
              <label class="msg-attach-label"><span class="msg-attach-button"><?= ui_icon('paperclip', 14) ?> Attach file</span><input type="file" name="attachment" accept=".jpg,.jpeg,.png,.gif,.webp,.pdf,.txt" data-file-label="#messageAttachmentName"><small id="messageAttachmentName">JPG, PNG, GIF, WEBP, PDF or TXT · 8 MB max</small></label>
            </div>
            <button class="btn btn-primary" type="submit"><?= ui_icon('send', 15) ?> <span>Send</span></button>
          </form>
          <div class="message-limit-note">
            <?= $messagesSentToday ?> of <?= $dailyMessageLimit ?> messages used today · <?= $messageMaxChars ?> characters per message
            <?php if (!$premium): ?> · <a href="<?= e(base_url('premium.php')) ?>">See Pro benefits</a><?php endif; ?>
          </div>
        <?php else: ?>
          <div class="empty-state" style="min-height:420px;display:flex;flex-direction:column;justify-content:center">
            <div class="es-ic"><?= ui_icon('chat') ?></div>
            <b>Pick a conversation</b>
            <p class="muted">Browse the marketplace and message a seller if you have questions before ordering.</p>
            <div><a class="btn btn-primary" href="<?= e(base_url('browse.php')) ?>">Browse services →</a></div>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<div class="note-detail-backdrop hidden" id="noteDetailBackdrop">
  <div class="note-detail" role="dialog" aria-modal="true" aria-labelledby="noteDetailTitle">
    <div class="note-detail-head">
      <div><span class="eyebrow">Message note</span><h3 id="noteDetailTitle">Note</h3></div>
      <button class="icon-btn" type="button" id="noteDetailClose" aria-label="Close note">✕</button>
    </div>
    <p id="noteDetailBody"></p>
    <small class="muted" id="noteDetailReplies"></small>
    <a class="btn btn-primary btn-sm" id="noteDetailReply" href="#">Reply to note</a>
  </div>
</div>

<!-- compose drawer -->
<div class="drawer-backdrop hidden" id="composeBackdrop">
  <div class="drawer" role="dialog" aria-modal="true" aria-labelledby="composeTitle">
    <div class="drawer-head">
      <h3 style="margin:0" id="composeTitle">New message</h3>
      <button class="icon-btn" type="button" id="composeClose" aria-label="Close">✕</button>
    </div>
    <form method="post" action="<?= e(base_url('messages.php')) ?>" class="drawer-body">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="compose">
      <div class="field">
        <label for="to">Message someone</label>
        <select class="input" id="to" name="to" required>
          <option value="">Choose a verified student…</option>
          <?php foreach ($sellers as $sl):
            if ((int) $sl['id'] === $uid) { continue; } ?>
            <option value="<?= (int) $sl['id'] ?>"><?= e($sl['full_name']) ?> · <?= e(profile_statuses()[(string) ($sl['profile_status'] ?? 'offline')]['label'] ?? 'Offline') ?><?= is_premium($sl) ? ' ★' : '' ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="body">First message</label>
        <textarea class="input" id="body" name="body" rows="5" maxlength="<?= $messageMaxChars ?>" required placeholder="Hi! I saw your listing and had a quick question…"><?= e($prefill) ?></textarea>
        <small class="muted"><?= $messagesSentToday ?> of <?= $dailyMessageLimit ?> messages used today · <?= $messageMaxChars ?> characters max</small>
      </div>
      <button class="btn btn-primary btn-block btn-lg" type="submit">Send message</button>
    </form>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>