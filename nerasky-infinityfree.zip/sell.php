<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$me = require_user();

$errors = [];
$uploadedImages = [];
$old = ['category' => '', 'title' => '', 'description' => '', 'price' => '', 'delivery_days' => 3];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if ($me['account_status'] !== 'verified') {
        flash('warn', 'Only verified accounts can post services.');
        redirect('dashboard.php');
    }
    if ($me['is_minor'] && $me['consent_status'] !== 'approved') {
        flash('warn', 'Your parental consent form must be approved before you can sell.');
        redirect('dashboard.php');
    }

    $old['category']      = (string) ($_POST['category'] ?? '');
    $old['title']         = trim((string) ($_POST['title'] ?? ''));
    $old['description']   = trim((string) ($_POST['description'] ?? ''));
    $old['price']         = (string) ($_POST['price'] ?? '');
    $old['delivery_days'] = max(1, min(30, (int) ($_POST['delivery_days'] ?? 3)));

    $price = clean_price($old['price']);

    if (!in_array($old['category'], CATEGORIES, true)) {
        $errors[] = 'Please choose a category.';
    }
    if (mb_strlen($old['title']) < 8 || mb_strlen($old['title']) > 140) {
        $errors[] = 'Title must be between 8 and 140 characters.';
    }
    if (mb_strlen($old['description']) < 40) {
        $errors[] = 'Give a little more detail (at least 40 characters) so buyers know exactly what they get.';
    }
    if ($price < 50) {
        $errors[] = 'Minimum price is ₱50. (Really — your time is worth it.)';
    }
    if ($price > 100000) {
        $errors[] = 'Price too high for a peer marketplace.';
    }

    $imageUploads = normalize_multi_uploads($_FILES['showcase_images'] ?? []);
    if (count($imageUploads) > MAX_SERVICE_IMAGES) {
        $errors[] = 'Choose up to ' . MAX_SERVICE_IMAGES . ' showcase images.';
    }
    if ($errors === []) {
        foreach ($imageUploads as $imageUpload) {
            [$uploaded, $path] = upload_service_image($imageUpload);
            if (!$uploaded) {
                $errors[] = $path;
                break;
            }
            $uploadedImages[] = $path;
        }
    }

    if ($errors === []) {
        $db = db();
        $db->beginTransaction();
        try {
            $serviceId = insert(
                'INSERT INTO services (seller_id, category, title, description, price, delivery_days, status)
                 VALUES (?,?,?,?,?,?,?)',
                [$me['id'], $old['category'], $old['title'], $old['description'], $price, $old['delivery_days'], 'pending']
            );
            foreach ($uploadedImages as $index => $imagePath) {
                q('INSERT INTO service_images (service_id, image_path, sort_order) VALUES (?,?,?)', [$serviceId, $imagePath, $index]);
            }
            $db->commit();
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            foreach ($uploadedImages as $imagePath) {
                $absolutePath = APP_ROOT . '/' . $imagePath;
                if (is_file($absolutePath)) {
                    unlink($absolutePath);
                }
            }
            throw $e;
        }
        notify_admins('moderation', $me['full_name'] . ' posted a new service for review: "' . mb_strimwidth($old['title'], 0, 40, '…') . '".', 'admin/services.php');
        flash('ok', 'Service posted! It goes live once a moderator gives it the green light.');
        redirect('dashboard.php');
    }

    if ($errors !== []) {
        foreach ($uploadedImages as $imagePath) {
            $absolutePath = APP_ROOT . '/' . $imagePath;
            if (is_file($absolutePath)) {
                unlink($absolutePath);
            }
        }
        $uploadedImages = [];
    }
}

$pageTitle  = 'Post a service';
$currentNav = 'sell';
require __DIR__ . '/includes/header.php';
?>
<section class="page-head sell-hero" style="background:var(--dark);padding:3rem 0 2.4rem">
  <div class="container sell-hero-inner">
    <div>
    <span class="eyebrow" style="color:#a5b4fc">Seller tools</span>
    <h1 style="color:#fff;font-size:2rem">Post a service</h1>
    <p style="color:#8b93b8;margin:0">Describe what you do, set your price, and start earning. You keep 95% of every order.</p>
    </div>
    <div class="sell-hero-stat"><strong>95%</strong><span>kept by you</span><i></i><strong>1</strong><span>clear review path</span></div>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <?php if ($me['account_status'] !== 'verified'): ?>
      <div class="banner banner-warn mb-3"><span class="b-ic"><?= ui_icon('lock') ?></span><span><b>You're almost there.</b> Posting services unlocks once a moderator verifies your account.</span></div>
    <?php elseif ($me['is_minor'] && $me['consent_status'] !== 'approved'): ?>
      <div class="banner banner-warn mb-3"><span class="b-ic"><?= ui_icon('users') ?></span><span><b>Parental consent pending.</b> Once an admin approves your signed consent form, you can post services.</span></div>
    <?php endif; ?>

    <div class="order-summary">
      <div class="stack">
        <?php foreach ($errors as $err): ?>
          <div class="banner banner-bad"><span class="b-ic">✕</span><span><?= e($err) ?></span></div>
        <?php endforeach; ?>

        <form method="post" enctype="multipart/form-data" action="<?= e(base_url('sell.php')) ?>" class="card card-pad sell-form-card reveal">
          <?= csrf_field() ?>
          <div class="grid-2 gap-2">
            <div class="field">
              <label for="category">Category</label>
              <select class="input" id="category" name="category" required>
                <option value="">Choose a category…</option>
                <?php foreach (CATEGORIES as $cat): ?>
                  <option value="<?= e($cat) ?>" <?= $old['category'] === $cat ? 'selected' : '' ?>><?= cat_icon($cat) ?> <?= e($cat) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="field">
              <label for="delivery_days">Delivery in (days)</label>
              <input class="input" type="number" id="delivery_days" name="delivery_days" min="1" max="30" value="<?= (int) $old['delivery_days'] ?>" required>
            </div>
          </div>
          <div class="field">
            <label for="title">Service title</label>
            <input class="input" id="title" name="title" maxlength="140" required value="<?= e($old['title']) ?>" placeholder="e.g. Algebra 101 crash course — 1 hour">
            <span class="hint">Be specific: 8–140 characters. Buyers scan fast.</span>
          </div>
          <div class="field">
            <label for="description">Description</label>
            <textarea class="input" id="description" name="description" rows="7" required placeholder="What exactly do you deliver? What's included? How should a buyer prepare? Style matters — write like a human."><?= e($old['description']) ?></textarea>
          </div>
          <div class="field">
            <label for="showcase_images">Showcase photos <span class="faint" style="font-weight:500">(optional)</span></label>
            <input class="input" id="showcase_images" name="showcase_images[]" type="file" accept="image/jpeg,image/png,image/webp" multiple>
            <span class="hint">Add up to <?= MAX_SERVICE_IMAGES ?> JPG, PNG, or WebP photos (max <?= MAX_UPLOAD_MB ?> MB each) so buyers can preview your work.</span>
          </div>
          <div class="grid-2 gap-2">
            <div class="field">
              <label for="price">Price</label>
              <div class="price-wrap">
                <span class="peso">₱</span>
                <input type="number" step="0.01" min="50" id="price" name="price" required placeholder="250" value="<?= e($old['price']) ?>">
              </div>
            </div>
            <div class="field">
              <label>&nbsp;</label>
              <div class="fee-break">
                <dl class="kv"><dt>You receive</dt><dd style="color:var(--green-600)">95% of every order</dd></dl>
                <dl class="kv" style="border-bottom:0"><dt>Platform fee</dt><dd>5% flat</dd></dl>
              </div>
            </div>
          </div>
          <button class="btn btn-primary btn-lg" type="submit" <?= $me['account_status'] !== 'verified' || ($me['is_minor'] && $me['consent_status'] !== 'approved') ? 'disabled' : '' ?>>Submit for review →</button>
        </form>
      </div>

      <aside class="stack">
        <div class="card card-pad">
          <h3 style="font-size:1rem"><?= ui_icon('zap') ?> Listing tips that work</h3>
          <div class="stack gap-2" style="gap:.8rem">
            <div class="flex" style="align-items:flex-start"><span class="st-ic" style="width:34px;height:34px;border-radius:10px;background:rgb(99 102 241/.1);display:flex;align-items:center;justify-content:center;flex-shrink:0">★</span><div><b style="font-size:var(--fs-sm)">Name the outcome</b><p class="muted" style="font-size:var(--fs-xs);margin:0">"I fix grammar mistakes" <i>vs</i> "an essay that reads like you wrote it confidently".</p></div></div>
            <div class="flex" style="align-items:flex-start"><span class="st-ic" style="width:34px;height:34px;border-radius:10px;background:rgb(245 158 11/.12);display:flex;align-items:center;justify-content:center;flex-shrink:0"><?= ui_icon('file') ?></span><div><b style="font-size:var(--fs-sm)">Scope the deliverable</b><p class="muted" style="font-size:var(--fs-xs);margin:0">"500 words", "1 hour session", "2 revisions" — clarity beats hype.</p></div></div>
            <div class="flex" style="align-items:flex-start"><span class="st-ic" style="width:34px;height:34px;border-radius:10px;background:rgb(16 185 129/.1);display:flex;align-items:center;justify-content:center;flex-shrink:0">⏱</span><div><b style="font-size:var(--fs-sm)">Promise a real timeline</b><p class="muted" style="font-size:var(--fs-xs);margin:0">Then deliver early. Reviews are the currency that matters here.</p></div></div>
          </div>
        </div>
        <div class="card card-pad" style="background:rgb(16 185 129/.05)">
          <h3 style="font-size:.95rem"><?= ui_icon('cash') ?> How payouts work</h3>
          <p class="muted" style="font-size:var(--fs-sm);margin:0">The buyer pays from their wallet or completes a PayMongo QR Ph checkout. Work starts after payment is confirmed. After the buyer accepts delivery, your payout is credited to your Nerasky wallet; request a manual withdrawal to your selected payout account.</p>
        </div>
      </aside>
    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>