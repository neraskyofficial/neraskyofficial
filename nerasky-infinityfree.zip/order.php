<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$orderId = (int) ($_GET['order'] ?? 0);
$fragment = (string) ($_GET['fragment'] ?? '');

$order = null;
if ($orderId > 0) {
    try {
        $order = row(
            'SELECT o.*, s.title AS service_title, s.category,
                    b.full_name AS buyer_name, b.premium_until AS buyer_premium,
                    s2.full_name AS seller_name, s2.premium_until AS seller_premium,
                    s2.created_at AS seller_joined_at, s.delivery_days
             FROM orders o
             JOIN services s  ON s.id = o.service_id
             JOIN users b     ON b.id = o.buyer_id
             JOIN users s2    ON s2.id = o.seller_id
             WHERE o.id = ?',
            [$orderId]
        );
    } catch (Throwable $e) {
        /* DB not installed yet */
    }
}

$me = get_user();

if (!$me || !$order) {
    flash('warn', 'That order doesn\'t exist or you don\'t have access to it.');
    redirect('dashboard.php');
}

$isBuyer  = (int) $me['id'] === (int) $order['buyer_id'];
$isSeller = (int) $me['id'] === (int) $order['seller_id'];
$isAdmin  = $me['role'] === 'admin';

if (!$isBuyer && !$isSeller && !$isAdmin) {
    flash('warn', 'That order doesn\'t belong to you.');
    redirect('dashboard.php');
}

$payments = rows('SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC', [$orderId]);
$latestPayment = $payments[0] ?? null;
$paymongoPayment = row(
    'SELECT id, amount_centavos, status, created_at, paid_at
     FROM paymongo_checkouts WHERE order_id = ? AND user_id = ? AND purpose = "order"
     ORDER BY id DESC LIMIT 1',
    [$orderId, (int) $order['buyer_id']]
);
$walletPayment = row('SELECT * FROM wallet_transactions WHERE order_id = ? AND type = "wallet_payment" AND direction = "debit" LIMIT 1', [$orderId]);
$review = row('SELECT * FROM reviews WHERE order_id = ?', [$orderId]);
$orderSellerIsPremium = is_premium(['premium_until' => $order['seller_premium']] ?? null);
$orderFeeRate = (float) $order['price'] > 0
    ? round(((float) $order['platform_fee'] / (float) $order['price']) * 100, 2)
    : (float) PLATFORM_FEE;
$deadlineState = order_deadline_state($order);
$sellerMetrics = seller_trust_metrics((int) $order['seller_id']);
$stepNow = match ($order['status']) {
    'awaiting_payment' => 1,
    'in_progress'      => 2,
    'delivered'        => 3,
    'completed'        => 4,
    default            => 0,
};
if ($walletPayment) {
    $paymentState = [
        'label' => 'Verified · Wallet payment',
        'class' => 'ok',
        'detail' => 'Payment was received from the buyer wallet.',
    ];
} elseif (($paymongoPayment['status'] ?? '') === 'succeeded') {
    $paymentState = [
        'label' => 'Paid · PayMongo QR Ph',
        'class' => 'ok',
        'detail' => 'PayMongo confirmed payment automatically.',
    ];
} elseif (($paymongoPayment['status'] ?? '') === 'pending') {
    $paymentState = [
        'label' => 'Waiting · PayMongo QR Ph',
        'class' => 'pending',
        'detail' => 'Scan the QR code and keep this page open while PayMongo confirms payment.',
    ];
} else {
    $paymentState = match ((string) ($latestPayment['status'] ?? '')) {
        'verified' => ['label' => 'Paid · GCash (verified)', 'class' => 'ok', 'detail' => 'A moderator verified the submitted GCash transaction.'],
        'pending' => ['label' => 'Waiting · GCash review', 'class' => 'pending', 'detail' => 'A moderator will verify the actual GCash transaction before work starts.'],
        'rejected' => ['label' => 'GCash proof rejected', 'class' => 'bad', 'detail' => 'Submit a new GCash payment proof or use PayMongo QR Ph.'],
        default => ['label' => 'Payment not submitted', 'class' => 'pending', 'detail' => 'The buyer must complete wallet, PayMongo QR Ph, or GCash payment before work can begin.'],
    };
}

$nextStep = match ((string) $order['status']) {
    'awaiting_payment' => $isBuyer
        ? ['title' => 'Step 1 of 4: Pay for this order', 'body' => 'Pay from your Nerasky wallet, use PayMongo QR Ph, or submit GCash proof for moderator review. Work starts only after payment is confirmed.', 'anchor' => '#payment']
        : ['title' => 'Step 1 of 4: Wait for payment confirmation', 'body' => 'Do not start work yet. You will be notified when the order changes to In progress.', 'anchor' => '#chat'],
    'in_progress' => $isSeller
        ? ['title' => 'Step 2 of 4: Complete and deliver the work', 'body' => 'Upload the finished file and add a short note so the buyer knows what to review.', 'anchor' => '#delivery']
        : ['title' => 'Step 2 of 4: Seller is working', 'body' => 'Keep questions and updates in the order chat. You will review the delivery next.', 'anchor' => '#chat'],
    'delivered' => $isBuyer
        ? ['title' => 'Step 3 of 4: Review the delivery', 'body' => 'Download the work, check it carefully, then accept and rate it to release the seller payout.', 'anchor' => '#review']
        : ['title' => 'Step 3 of 4: Delivery sent to the buyer', 'body' => 'The payout is released after the buyer accepts the work. Keep an eye on the order chat.', 'anchor' => '#chat'],
    'completed' => ['title' => 'Step 4 of 4: Order complete', 'body' => 'The buyer accepted the work and the seller payout has been released.', 'anchor' => '#help'],
    'cancelled' => ['title' => 'Order cancelled', 'body' => 'No further action is needed. If something went wrong, use the support link below.', 'anchor' => '#help'],
    default => ['title' => 'Next step', 'body' => 'Keep order updates and questions in the in-platform chat.', 'anchor' => '#chat'],
};

/* ---------------- actions ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'pay_proof' && $isBuyer && $order['status'] === 'awaiting_payment') {
        if (!ENABLE_EXTERNAL_PAYMENTS) {
            flash('bad', 'Manual GCash payments are not configured. You can use PayMongo QR Ph or your Nerasky wallet.');
            redirect('order.php?order=' . $orderId);
        }
        $provider = in_array($_POST['provider'] ?? '', PAYMENT_METHODS, true) ? (string) $_POST['provider'] : '';
        $reference = trim((string) ($_POST['reference'] ?? ''));
        if ($provider === '' || mb_strlen($reference) < 5 || mb_strlen($reference) > 60) {
            flash('bad', 'Enter a valid GCash transaction reference.');
            redirect('order.php?order=' . $orderId);
        }
        if (row('SELECT id FROM payments WHERE provider = ? AND reference_number = ?', [$provider, $reference])) {
            flash('bad', 'That GCash transaction reference has already been submitted.');
            redirect('order.php?order=' . $orderId);
        }
        $proof = upload_file($_FILES['screenshot'] ?? [], 'proofs', ['jpg', 'jpeg', 'png', 'webp']);
        if (!$proof[0]) {
            flash('bad', 'Payment screenshot: ' . $proof[1]);
            redirect('order.php?order=' . $orderId);
        }
        $db = db();
        $db->beginTransaction();
        try {
            $lockedOrder = row('SELECT id, status FROM orders WHERE id = ? AND buyer_id = ? FOR UPDATE', [$orderId, (int) $me['id']]);
            $activeCheckout = row(
                "SELECT id FROM paymongo_checkouts WHERE order_id = ? AND user_id = ? AND purpose = 'order' AND status IN ('pending','succeeded') LIMIT 1",
                [$orderId, (int) $me['id']]
            );
            $paidWallet = row(
                "SELECT id FROM wallet_transactions WHERE order_id = ? AND type = 'wallet_payment' AND direction = 'debit' LIMIT 1",
                [$orderId]
            );
            $activeProof = row("SELECT id FROM payments WHERE order_id = ? AND status IN ('pending','verified') LIMIT 1", [$orderId]);
            if (!$lockedOrder || $lockedOrder['status'] !== 'awaiting_payment' || $activeCheckout || $paidWallet || $activeProof) {
                throw new RuntimeException('This order already has a payment in progress or has been paid. Refresh the order page before trying again.');
            }
            insert(
                'INSERT INTO payments (order_id, payer_id, provider, reference_number, screenshot_file, status) VALUES (?,?,?,?,?,?)',
                [$orderId, (int) $me['id'], $provider, $reference, $proof[1], 'pending']
            );
            insert('INSERT INTO messages (order_id, sender_id, body, is_read) VALUES (?,?,?,0)',
                [$orderId, (int) $me['id'], 'GCash payment proof submitted (ref ' . $reference . '). Awaiting moderator verification.']);
            $db->commit();
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            @unlink(APP_ROOT . '/' . $proof[1]);
            flash('bad', $e instanceof RuntimeException ? $e->getMessage() : 'Could not submit the GCash proof. Please try again.');
            redirect('order.php?order=' . $orderId);
        }
        notify_admins('payment', $me['full_name'] . ' submitted a GCash payment proof for order #' . $orderId . '.', 'payments.php?review=' . $orderId);
        flash('ok', 'GCash payment proof submitted. Your order starts after an admin verifies the payment.');
        redirect('order.php?order=' . $orderId);
    }

    if ($action === 'pay_wallet' && $isBuyer && $order['status'] === 'awaiting_payment') {
        $db = db();
        $db->beginTransaction();
        try {
            $lockedOrder = row(
                'SELECT id, status FROM orders WHERE id = ? AND buyer_id = ? FOR UPDATE',
                [$orderId, (int) $me['id']]
            );
            $activeProof = row("SELECT id FROM payments WHERE order_id = ? AND status IN ('pending','verified') LIMIT 1", [$orderId]);
            $activeCheckout = row(
                "SELECT id FROM paymongo_checkouts WHERE order_id = ? AND user_id = ? AND purpose = 'order' AND status IN ('pending','succeeded') LIMIT 1",
                [$orderId, (int) $me['id']]
            );
            if (!$lockedOrder || $lockedOrder['status'] !== 'awaiting_payment' || $activeProof || $activeCheckout) {
                throw new RuntimeException('Another payment is already pending or has been received for this order. Check its payment status before trying again.');
            }
            if (!wallet_debit((int) $me['id'], (float) $order['price'], 'Wallet payment for order #' . $orderId, $orderId, 'wallet_payment')) {
                throw new DomainException('You do not have enough wallet balance to pay this order.');
            }
            q('UPDATE orders SET status = "in_progress" WHERE id = ? AND status = "awaiting_payment"', [$orderId]);
            insert('INSERT INTO messages (order_id, sender_id, body, is_read) VALUES (?,?,?,0)',
                [$orderId, $me['id'], 'Wallet payment received. The seller can now begin work.' ]);
            notify((int) $order['seller_id'], 'payment', 'Wallet payment received for order #' . $orderId . '. You can start working.', 'order.php?order=' . $orderId);
            $db->commit();
            flash('ok', 'Wallet payment received. The order is now in progress.');
            redirect('order.php?order=' . $orderId);
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            flash($e instanceof DomainException ? 'bad' : 'warn', $e->getMessage());
            redirect('order.php?order=' . $orderId);
        }
    }

    if ($action === 'deliver' && $isSeller && $order['status'] === 'in_progress') {
        $up = upload_file($_FILES['deliverable'] ?? [], 'works', ['jpg', 'jpeg', 'png', 'webp', 'pdf', 'zip', 'docx', 'doc', 'pptx', 'txt']);
        $note = trim((string) ($_POST['delivery_note'] ?? ''));
        if (!$up[0]) {
            flash('bad', 'Deliverable: ' . $up[1]);
        } else {
            q('UPDATE orders SET status = "delivered", deliverable_file = ? WHERE id = ?', [$up[1], $orderId]);
            if ($note !== '') {
                insert('INSERT INTO messages (order_id, sender_id, body, is_read) VALUES (?,?,?,0)', [$orderId, $me['id'], 'Deliverable uploaded! ' . $note]);
            }
            notify((int) $order['buyer_id'], 'delivered', 'Deliverable uploaded for order #' . $orderId . ' — review it to release the payout.', 'order.php?order=' . $orderId);
            flash('ok', 'Work delivered to the buyer! Waiting for their review.');
            redirect('order.php?order=' . $orderId);
        }
    }

    if ($action === 'accept' && $isBuyer && $order['status'] === 'delivered') {
        $rating  = max(1, min(5, (int) ($_POST['rating'] ?? 5)));
        $comment = trim((string) ($_POST['review_comment'] ?? ''));
        q("UPDATE orders SET status = 'completed', completed_at = NOW() WHERE id = ?", [$orderId]);
        insert('INSERT INTO reviews (order_id, reviewer_id, reviewee_id, rating, comment) VALUES (?,?,?,?,?)',
            [$orderId, $me['id'], $order['seller_id'], $rating, $comment]);
        wallet_credit((int) $order['seller_id'], (float) $order['seller_payout'], 'Order payout for #' . $orderId, $orderId, 'order_payout');
        insert('INSERT INTO messages (order_id, sender_id, body, is_read) VALUES (?,?,?,0)',
            [$orderId, $me['id'], 'Order completed — rated ' . $rating . '★. Payout released to the seller.' ]);
        notify((int) $order['seller_id'], 'payout', '₱' . number_format((float) $order['seller_payout'], 2) . ' released to your wallet for order #' . $orderId . '.', 'wallet.php');
        flash('ok', 'Order completed! ' . money((float) $order['seller_payout']) . ' released to the seller\'s wallet.');
        redirect('order.php?order=' . $orderId);
    }

    if ($action === 'cancel' && ($isBuyer || $isAdmin) && in_array($order['status'], ['awaiting_payment', 'in_progress'], true)) {
        q("UPDATE orders SET status = 'cancelled' WHERE id = ?", [$orderId]);
        if ($walletPayment) {
            wallet_credit((int) $order['buyer_id'], (float) $order['price'], 'Refund for cancelled order #' . $orderId, $orderId, 'refund');
        } elseif (($paymongoPayment['status'] ?? '') === 'succeeded' || ($latestPayment['status'] ?? '') === 'verified') {
            notify_admins(
                'payment',
                'Paid order #' . $orderId . ' was cancelled. Review the external payment and arrange a refund if appropriate.',
                'payments.php'
            );
            notify(
                (int) $order['buyer_id'],
                'payment',
                'Order #' . $orderId . ' was cancelled. Because this payment was made outside your Nerasky wallet, contact support to arrange a refund review.',
                'support.php'
            );
        }
        flash('info', 'Order cancelled.');
        redirect('order.php?order=' . $orderId);
    }

    if ($action === 'dispute' && ($isBuyer || $isSeller) && !in_array($order['status'], ['completed', 'cancelled'], true)) {
        $reason = trim((string) ($_POST['reason'] ?? ''));
        if ($reason === '') {
            flash('bad', 'Please describe what needs help before sending the request.');
            redirect('order.php?order=' . $orderId . '#help');
        } else {
            $reason = mb_substr($reason, 0, 700);
            notify_admins('order', $me['full_name'] . ' requested help with order #' . $orderId . ': ' . $reason, 'order.php?order=' . $orderId);
            $otherParty = $isBuyer ? (int) $order['seller_id'] : (int) $order['buyer_id'];
            notify($otherParty, 'order', $me['full_name'] . ' requested help with order #' . $orderId . '. Please review the order chat.', 'order.php?order=' . $orderId);
            insert('INSERT INTO messages (order_id, sender_id, body, is_read) VALUES (?,?,?,0)',
                [$orderId, $me['id'], 'Help/dispute request sent to Nerasky support: ' . $reason]);
            flash('ok', 'Your support request was sent. Keep updates in this order chat while we review it.');
            redirect('order.php?order=' . $orderId);
        }
    }

    if ($action === 'send_message' && ($isBuyer || $isSeller)) {
        $body = trim((string) ($_POST['body'] ?? ''));
        if ($body !== '') {
            insert('INSERT INTO messages (order_id, sender_id, body, is_read) VALUES (?,?,?,0)', [$orderId, $me['id'], $body]);
        }
        redirect('order.php?order=' . $orderId);
    }

    flash('bad', 'That action isn\'t allowed right now.');
    redirect('order.php?order=' . $orderId);
}
/* Mark incoming messages as read */
q('UPDATE messages SET is_read = 1 WHERE order_id = ? AND sender_id <> ? AND is_read = 0', [$orderId, $me['id']]);

$messages = rows('SELECT m.*, u.full_name, u.profile_frame, u.profile_accent FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.order_id = ? ORDER BY m.id ASC', [$orderId]);

if ($fragment === 'messages') {
    header('Content-Type: text/html; charset=UTF-8');
    echo chat_messages_html($messages, $me['id']);
    exit;
}

$pageTitle = 'Order #' . $orderId;
$currentNav = 'orders';
require __DIR__ . '/includes/header.php';
?>

<?php
function chat_messages_html(array $msgs, int $myId): string
{
    $out = '';
    $lastDay = null;
    foreach ($msgs as $m) {
        $day = date('Y-m-d', strtotime((string) $m['created_at']));
        if ($day !== $lastDay) {
            $out .= '<div class="msg-day">' . date('M j', strtotime((string) $m['created_at'])) . '</div>';
            $lastDay = $day;
        }
        $mine = (int) $m['sender_id'] === $myId;
        $out .= '<div class="msg ' . ($mine ? 'sent' : '') . '">'
            . ($mine ? '' : avatar_of($m, 32))
            . '<div><div class="msg-bub"><p class="msg-body">' . e($m['body']) . '</p></div>'
            . '<div class="msg-meta">' . e(explode(' ', $m['full_name'])[0]) . ' · ' . date('g:i A', strtotime((string) $m['created_at'])) . '</div></div></div>';
    }
    return $out !== '' ? $out : '<div class="empty-state" style="padding:2rem"><div class="es-ic">' . ui_icon('chat') . '</div><b>No messages yet</b><p class="muted" style="margin:0">Say hi and agree on details here — everything stays inside Nerasky.</p></div>';
}
?>
<section class="section-tight">
  <div class="container">
    <div class="flex-between mb-2">
      <div class="flex">
        <a class="btn btn-ghost btn-sm" href="<?= e(base_url('orders.php')) ?>">← Orders</a>
        <h1 style="font-size:1.6rem;margin:0">Order #<?= (int) $order['id'] ?></h1>
        <?= sb((string) $order['status']) ?>
      </div>
      <div class="flex gap-2">
        <?php if ($isBuyer): ?>
          <a class="btn btn-outline btn-sm" href="<?= e(base_url('messages.php?to=' . (int) $order['seller_id'])) ?>"><?= ui_icon('chat') ?> Message seller</a>
          <a class="btn btn-ghost btn-sm" href="<?= e(base_url('profile.php?id=' . (int) $order['seller_id'])) ?>"><?= ui_icon('users') ?> Seller profile</a>
        <?php elseif ($isSeller): ?>
          <a class="btn btn-outline btn-sm" href="<?= e(base_url('messages.php?to=' . (int) $order['buyer_id'])) ?>"><?= ui_icon('chat') ?> Message buyer</a>
          <a class="btn btn-ghost btn-sm" href="<?= e(base_url('profile.php?id=' . (int) $order['buyer_id'])) ?>"><?= ui_icon('users') ?> Buyer profile</a>
        <?php endif; ?>
        <span class="muted" style="font-size:var(--fs-xs)">Placed <?= time_ago((string) $order['created_at']) ?></span>
      </div>
    </div>

    <div class="banner banner-info mb-3 order-next-step" id="next-step">
      <span class="b-ic"><?= ui_icon('zap') ?></span>
      <span><b><?= e($nextStep['title']) ?></b> <?= e($nextStep['body']) ?>
        <a class="btn btn-primary btn-sm" href="<?= e($nextStep['anchor']) ?>" style="margin-left:.6rem">Continue →</a>
        <a class="btn btn-ghost btn-sm" id="help" href="<?= e(base_url('guide.php#faq')) ?>">Need help or dispute?</a>
      </span>
    </div>

    <div class="order-payment-status order-payment-status-<?= e($paymentState['class']) ?> mb-3">
      <span class="order-payment-status-icon"><?= $paymentState['class'] === 'ok' ? '✓' : ($paymentState['class'] === 'bad' ? '!' : '…') ?></span>
      <div><b><?= e($paymentState['label']) ?></b><span><?= e($paymentState['detail']) ?></span></div>
    </div>

    <div class="card card-pad mb-3" aria-label="Order protection timeline">
      <div class="flex-between" style="gap:1rem;align-items:flex-start">
        <div>
          <h3 style="font-size:1.05rem;margin:0 0 .25rem"><?= ui_icon('shield') ?> Order protection timeline</h3>
          <p class="muted" style="font-size:var(--fs-sm);margin:0">Your payment is held until you accept the delivered work. The promised delivery window is based on the service listing.</p>
        </div>
        <?php if ($deadlineState['deadline']): ?>
          <?php $deadlineLabel = $deadlineState['deadline']->format('M j, Y'); ?>
          <span class="chip" style="<?= $deadlineState['overdue'] ? 'color:var(--red-600);background:rgb(239 68 68/.1)' : '' ?>">
            <?= $deadlineState['overdue'] ? 'Overdue · ' . e($deadlineLabel) : 'Due by ' . e($deadlineLabel) ?>
          </span>
        <?php endif; ?>
      </div>
      <div class="order-flow" style="margin-top:1rem">
        <?php foreach ([['1', 'Payment'], ['2', 'Work started'], ['3', 'Delivered'], ['4', 'Completed']] as $i => $f):
          $n = $i + 1; ?>
          <span class="flow-step <?= $stepNow > $n || $order['status'] === 'completed' ? 'done' : ($stepNow === $n ? 'now' : '') ?>">
            <span class="fs-n"><?= $stepNow > $n || $order['status'] === 'completed' ? '✓' : $n ?></span><?= $f[1] ?>
          </span>
          <?php if ($n < 4): ?><span class="flow-arrow">→</span><?php endif; ?>
        <?php endforeach; ?>
      </div>
      <?php if ($deadlineState['overdue'] && in_array($order['status'], ['in_progress', 'awaiting_payment'], true)): ?>
        <div class="banner banner-bad mt-2"><span class="b-ic">!</span><span>This order is past its listed delivery window. You can request help below; your payment remains protected until acceptance.</span></div>
      <?php endif; ?>
    </div>

    <div class="order-summary">
      <div class="stack">
        <div class="card card-pad">
          <div class="flex-between mb-2">
            <h3 style="font-size:1.05rem;margin:0"><a href="<?= e(base_url('service.php?id=' . (int) $order['service_id'])) ?>" style="color:inherit"><?= e($order['service_title']) ?></a></h3>
            <span class="sv-cat" style="font-size:var(--fs-xs);font-weight:700;color:var(--brand-600);background:rgb(99 102 241/.08);padding:.3rem .7rem;border-radius:var(--r-pill)">
              <?= cat_icon((string) $order['category']) ?> <?= e($order['category']) ?>
            </span>
          </div>
          <dl class="kv"><dt>Buyer</dt><dd><?= e(member_name($order, 'buyer_name')) ?></dd></dl>
          <dl class="kv"><dt>Seller</dt><dd><?= e(member_name($order, 'seller_name')) ?> <?php if ($orderSellerIsPremium): ?><?= premium_badge() ?><?php endif; ?></dd></dl>
          <dl class="kv"><dt>Order total</dt><dd><?= money((float) $order['price']) ?></dd></dl>
          <dl class="kv"><dt>Seller payout (<?= 100 - $orderFeeRate ?>%)</dt><dd style="color:var(--green-600)"><?= money((float) $order['seller_payout']) ?></dd></dl>
          <dl class="kv" style="border-bottom:0"><dt>Platform fee (<?= $orderFeeRate ?>%)</dt><dd><?= money((float) $order['platform_fee']) ?></dd></dl>
          <?php if (trim((string) $order['notes']) !== ''): ?>
            <div class="filebox mt-2" style="background:#fff">
              <span class="f-ic"><?= ui_icon('pen') ?></span><b>Buyer notes</b>
              <span style="color:var(--muted);font-size:var(--fs-sm);font-weight:500"><?= e($order['notes']) ?></span>
            </div>
          <?php endif; ?>
          <div class="card" style="padding:1rem;background:rgb(99 102 241/.04);border-color:rgb(99 102 241/.12)">
           <h4 style="margin:0 0 .6rem">Seller trust metrics</h4>
           <div class="grid-2 gap-2" style="font-size:var(--fs-sm)">
             <div><span class="muted">Completed orders</span><br><b><?= (int) $sellerMetrics['completed'] ?></b></div>
             <div><span class="muted">Cancellation rate</span><br><b><?= $sellerMetrics['cancellation_rate'] === null ? 'Not enough data' : e(number_format((float) $sellerMetrics['cancellation_rate'], 1) . '%') ?></b></div>
             <div><span class="muted">Member since</span><br><b><?= $order['seller_joined_at'] ? e(date('M Y', strtotime((string) $order['seller_joined_at']))) : '—' ?></b></div>
             <?php if (($responseLabel = seller_response_time_label($sellerMetrics['response_hours'])) !== null): ?><div><span class="muted">Typical first response</span><br><b><?= e($responseLabel) ?></b></div><?php endif; ?>
           </div>
          </div>
          <?php if ($order['deliverable_file']): ?>
            <div class="filebox mt-2">
              <span class="f-ic"><?= ui_icon('box') ?></span><b>Deliverable</b>
              <a class="btn btn-sm btn-primary" href="<?= e(asset_url((string) $order['deliverable_file'])) ?>" target="_blank" style="margin-left:auto">Download</a>
            </div>
          <?php endif; ?>
        </div>
<?php if ($isBuyer || $isAdmin): ?>
        <div class="card card-pad" id="payment">
          <div class="flex-between mb-2">
            <h3 style="font-size:1.05rem;margin:0"><?= ui_icon('card') ?> Step 1: Payment</h3>
            <?= sb((string) ($paymongoPayment['status'] ?? ($walletPayment ? 'paid' : 'pending'))) ?>
          </div>
          <p class="muted" style="font-size:var(--fs-sm)">Pay securely with your Nerasky wallet or a PayMongo QR Ph checkout. Payments are confirmed automatically before work begins.</p>

          <?php if ($isBuyer && $order['status'] === 'awaiting_payment'): ?>
            <div class="card" style="padding:1rem;background:rgb(99 102 241/.05);border-color:rgb(99 102 241/.14)">
              <div class="flex-between" style="gap:1rem;align-items:flex-start">
                <div>
                  <b><?= ui_icon('wallet') ?> Pay from your Nerasky wallet</b>
                  <p class="muted" style="font-size:var(--fs-sm);margin:.25rem 0 0">Available balance: <strong><?= money((float) $me['wallet']) ?></strong>. Funds stay protected until you accept the work.</p>
                </div>
                <?php if ((float) $me['wallet'] >= (float) $order['price']): ?>
                  <form method="post" action="<?= e(base_url('order.php?order=' . $orderId)) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="pay_wallet">
                    <button class="btn btn-primary btn-sm" type="submit">Pay <?= price((float) $order['price']) ?></button>
                  </form>
                <?php else: ?>
                  <a class="btn btn-outline btn-sm" href="<?= e(base_url('wallet.php')) ?>">Add cash</a>
                <?php endif; ?>
              </div>
            </div>
            <?php
            $checkoutPurpose = 'order';
            $checkoutOrderId = $orderId;
            $checkoutAmount = (float) $order['price'];
            $checkoutButton = 'Pay securely with QR Ph';
            require __DIR__ . '/includes/paymongo_checkout_ui.php';
            ?>
            <?php if (($latestPayment['status'] ?? '') === 'pending'): ?>
              <div class="banner banner-info mt-2"><span class="b-ic"><?= ui_icon('clock') ?></span><span>GCash reference <b><?= e((string) $latestPayment['reference_number']) ?></b> is waiting for admin review. Do not pay again while this request is pending.</span></div>
            <?php elseif (($latestPayment['status'] ?? '') === 'rejected'): ?>
              <div class="banner banner-warn mt-2"><span class="b-ic">!</span><span>Your last GCash proof was rejected. Submit a corrected proof or use PayMongo QR Ph.</span></div>
            <?php endif; ?>
            <?php if (ENABLE_EXTERNAL_PAYMENTS && !in_array((string) ($latestPayment['status'] ?? ''), ['pending', 'verified'], true)
                && ($paymongoPayment['status'] ?? '') !== 'pending'
                && !$walletPayment): ?>
              <div class="card card-pad mt-2">
                <h3 style="font-size:1.05rem"><?= ui_icon('cash') ?> Or pay directly with GCash</h3>
                <?php
                $gcashAccount = payment_account_details('GCash');
                $gcashInstructions = 'Scan the InstaPay QR with GCash or another supported QR Ph app. Pay exactly ' . money((float) $order['price']) . ' and include order #' . $orderId . ' in the payment note. Work starts only after an admin verifies the actual transaction.';
                require __DIR__ . '/includes/gcash_payment_card.php';
                ?>
                <form method="post" enctype="multipart/form-data" class="mt-2" action="<?= e(base_url('order.php?order=' . $orderId)) ?>">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="pay_proof">
                  <input type="hidden" name="provider" value="GCash">
                  <div class="field">
                    <label for="payment_reference">GCash transaction reference</label>
                    <input class="input" id="payment_reference" name="reference" required maxlength="60" placeholder="Reference number from GCash">
                  </div>
                  <div class="field">
                    <label for="payment_screenshot">Payment screenshot</label>
                    <input class="input" type="file" id="payment_screenshot" name="screenshot" accept=".jpg,.jpeg,.png,.webp" required>
                    <small class="hint">JPG, PNG, or WEBP · up to 6 MB. Show the paid amount, date, and reference.</small>
                  </div>
                  <button class="btn btn-outline btn-block" type="submit">Submit GCash proof for admin review</button>
                </form>
              </div>
            <?php endif; ?>
          <?php endif; ?>
        </div>
        <?php endif; ?>
</div>
<aside class="stack">
        <?php if ($isSeller && $order['status'] === 'in_progress'): ?>
          <div class="card card-pad" id="delivery">
            <h3 style="font-size:1.05rem;margin-bottom:.9rem"><?= ui_icon('box') ?> Step 2: Deliver the work</h3>
            <form method="post" enctype="multipart/form-data" action="<?= e(base_url('order.php?order=' . $orderId)) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="deliver">
              <div class="field">
                <label for="deliverable">File (PDF, ZIP, DOCX, image…)</label>
                <div class="dropzone">
                  <div class="dz-ic"><?= ui_icon('file') ?></div>
                  <b><span id="deliverLabel">Click to attach deliverable</span></b>
                  <small>Up to 6 MB</small>
                  <input class="hidden" type="file" id="deliverable" name="deliverable" data-file-label="#deliverLabel">
                </div>
              </div>
              <div class="field">
                <label for="delivery_note">Message to the buyer <span class="faint" style="font-weight:500">(optional)</span></label>
                <textarea class="input" id="delivery_note" name="delivery_note" rows="3" placeholder="Here's what I did + how to open it…"></textarea>
              </div>
              <button class="btn btn-primary btn-block" type="submit">Mark as delivered</button>
            </form>
          </div>
        <?php elseif ($isBuyer && $order['status'] === 'delivered'): ?>
          <div class="card card-pad" id="review">
            <h3 style="font-size:1.05rem;margin-bottom:.4rem"><?= ui_icon('star') ?> Step 3: Review &amp; complete</h3>
            <p class="muted" style="font-size:var(--fs-sm)">Done? Accept the deliverable, rate the work and release the payout to the seller.</p>
            <form method="post" action="<?= e(base_url('order.php?order=' . $orderId)) ?>" class="mt-2">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="accept">
              <div class="field">
                <label>Your rating</label>
                <div class="flex gap-2" data-rating>
                  <input type="hidden" name="rating" value="5">
                  <?php for ($i = 1; $i <= 5; $i++): ?><span class="rate-star" style="cursor:pointer;font-size:1.6rem;color:var(--line-2);transition:color .12s ease">★</span><?php endfor; ?>
                </div>
              </div>
              <div class="field">
                <label for="review_comment">Comment <span class="faint" style="font-weight:500">(optional)</span></label>
                <textarea class="input" id="review_comment" name="review_comment" rows="3" placeholder="How was the experience?"></textarea>
              </div>
              <button class="btn btn-primary btn-block" type="submit">Accept · release ₱<?= number_format((float) $order['seller_payout'], 0) ?> →</button>
            </form>
          </div>
        <?php elseif ($order['status'] === 'completed'): ?>
          <div class="card card-pad">
            <h3 style="font-size:1.05rem;margin-bottom:.5rem"><?= ui_icon('sparkle') ?> Order complete</h3>
            <?php if ($review): ?>
              <div class="mb-1"><?= star_row((float) $review['rating']) ?> <span class="muted" style="font-size:var(--fs-sm)"><?= number_format((float) $review['rating'], 1) ?> / 5</span></div>
              <?php if (trim((string) $review['comment'])): ?><p class="muted" style="font-size:var(--fs-sm)">"<?= e($review['comment']) ?>"</p><?php endif; ?>
            <?php endif; ?>
            <p class="muted" style="font-size:var(--fs-sm);margin:0"><?= money((float) $order['seller_payout']) ?> went to the seller — <?= money((float) $order['platform_fee']) ?> stayed with the platform.</p>
          </div>
        <?php elseif ($order['status'] === 'cancelled'): ?>
          <div class="card card-pad"><div class="banner banner-info"><span class="b-ic"><?= ui_icon('info') ?></span><span>This order was cancelled. No payment was released.</span></div></div>
        <?php endif; ?>

        <?php if (($isBuyer && in_array($order['status'], ['awaiting_payment'], true)) || $isAdmin): ?>
          <form method="post" action="<?= e(base_url('order.php?order=' . $orderId)) ?>" onsubmit="return confirm('Cancel this order?')">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="cancel">
            <button class="btn btn-danger btn-block" type="submit">Cancel order</button>
          </form>
        <?php endif; ?>
        <?php if (($isBuyer || $isSeller) && !in_array($order['status'], ['completed', 'cancelled'], true)): ?>
          <div class="card card-pad" id="help">
            <h3 style="font-size:1.05rem;margin-bottom:.35rem"><?= ui_icon('shield') ?> Need help or dispute?</h3>
            <p class="muted" style="font-size:var(--fs-sm)">Send a protected support request to the Nerasky team. We’ll notify the other party and keep the request in this order’s chat.</p>
            <form method="post" action="<?= e(base_url('order.php?order=' . $orderId)) ?>">
              <?= csrf_field() ?><input type="hidden" name="action" value="dispute">
              <textarea class="input" name="reason" rows="3" maxlength="700" required placeholder="Tell us what happened or what you need resolved"></textarea>
              <button class="btn btn-outline btn-block mt-2" type="submit">Request help from Nerasky</button>
            </form>
          </div>
        <?php endif; ?>
      </aside>
    </div>

    <!-- chat -->
    <div class="card mt-3" id="chat">
      <div class="panel-head">
        <div class="flex">
          <span style="font-size:1.2rem"><?= ui_icon('chat') ?></span>
          <div>
            <h3 style="margin:0">In-platform chat</h3>
            <span class="ph-sub">Stays here — no contact info, no third-party messengers.</span>
          </div>
        </div>
      </div>
      <div class="chat-box" id="chat-box" data-order="<?= (int) $orderId ?>"><?= chat_messages_html($messages, (int) $me['id']) ?></div>
      <?php if ($order['status'] !== 'cancelled' && ($isBuyer || $isSeller)): ?>
        <form method="post" action="<?= e(base_url('order.php?order=' . $orderId)) ?>" class="container" style="padding:1rem 1.4rem">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="send_message">
          <div class="chat-input">
            <textarea class="input" name="body" rows="2" maxlength="1000" placeholder="Say something friendly and specific…"></textarea>
            <button class="btn btn-primary" type="submit">Send</button>
          </div>
        </form>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>