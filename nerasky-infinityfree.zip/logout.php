<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

logout_user();
flash('info', 'You have been signed out. See you soon!');
redirect('index.php');