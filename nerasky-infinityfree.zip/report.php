<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$me = require_user();
$type = in_array((string) ($_GET['type'] ?? ''), ['service', 'user', 'order'], true) ? (string) $_GET['type'] : 'service';
$targetId = max(0, (int) ($_GET['id'] ?? 0));
$targetUser = null;
$errors = [];
$reasonOptions = $type === 'user'
    ? ['Fraud or scam', 'Harassment or bullying', 'Unsafe or inappropriate behavior', 'Impersonation or fake identity', 'Academic dishonesty', 'Spam or repeated unwanted contact', 'Other']
    : ['Fraud or scam', 'Harassment or unsafe behavior', 'Misleading service', 'Payment issue', 'Other'];

if ($type === 'user' && $targetId > 0) {
    $targetUser = row("SELECT id, full_name, role FROM users WHERE id = ? AND role <> 'admin'", [$targetId]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $reason = trim((string) ($_POST['reason'] ?? ''));
    $details = trim((string) ($_POST['details'] ?? ''));

    if ($targetId < 1 || ($type === 'user' && (!$targetUser || $targetId === (int) $me['id']))) {
        $errors[] = 'That user is not available to report.';
    } elseif (!in_array($reason, $reasonOptions, true) || mb_strlen($details) < 10 || mb_strlen($details) > 2000) {
        $errors[] = 'Choose a reason and explain what happened in 10–2,000 characters.';
    } elseif (!throttle_allows('report:' . (int) $me['id'], 5, 3600)) {
        $errors[] = 'You have sent several reports recently. Please wait ' . ceil(throttle_retry_after('report:' . (int) $me['id']) / 60) . ' minute(s) before sending another.';
    } else {
        insert('INSERT INTO platform_reports (reporter_id,target_type,target_id,reason,details) VALUES (?,?,?,?,?)', [(int) $me['id'], $type, $targetId, $reason, $details]);
        notify_admins('report', $me['full_name'] . ' submitted a ' . $type . ' report.', 'support.php');
        flash('ok', 'Thanks. Your report was sent to the trust and safety team.');
        redirect($type === 'user' ? 'profile.php?id=' . $targetId : 'dashboard.php');
    }
}

if ($type === 'user' && (!$targetUser || $targetId === (int) $me['id'])) {
    $errors[] = 'That user is not available to report.';
}

$pageTitle = $type === 'user' ? 'Report a user' : 'Report an issue';
$currentNav = '';
require __DIR__ . '/includes/header.php';
?>
<section class="section">
  <div class="container" style="max-width:680px">
    <span class="eyebrow">Trust &amp; safety</span>
    <h1><?= $type === 'user' ? 'Report a user' : 'Report an issue' ?></h1>
    <?php if ($type === 'user' && $targetUser): ?>
      <p class="muted">You’re reporting <b><?= e($targetUser['full_name']) ?></b>. Our team reviews reports privately and will follow up if more information is needed.</p>
    <?php else: ?>
      <p class="muted">Tell us what happened. Reports are reviewed by the Nerasky team. Do not share passwords, one-time codes, or payment PINs.</p>
    <?php endif; ?>
    <?php foreach (array_unique($errors) as $error): ?><div class="banner banner-bad"><span class="b-ic">!</span><?= e($error) ?></div><?php endforeach; ?>
    <?php if ($type !== 'user' || ($targetUser && $targetId !== (int) $me['id'])): ?>
      <form method="post" class="card card-pad">
        <?= csrf_field() ?>
        <div class="field">
          <label for="reason">Reason</label>
          <select class="input" id="reason" name="reason" required>
            <option value="">Choose one</option>
            <?php foreach ($reasonOptions as $option): ?><option value="<?= e($option) ?>" <?= (string) ($_POST['reason'] ?? '') === $option ? 'selected' : '' ?>><?= e($option) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label for="details">What happened?</label>
          <textarea class="input" id="details" name="details" rows="6" minlength="10" maxlength="2000" required><?= e((string) ($_POST['details'] ?? '')) ?></textarea>
          <small class="muted">Include useful details such as when it happened or a related order. Do not include passwords, one-time codes, or payment PINs.</small>
        </div>
        <div class="flex gap-1">
          <button class="btn btn-primary" type="submit">Submit report</button>
          <?php if ($type === 'user'): ?><a class="btn btn-outline" href="<?= e(base_url('profile.php?id=' . $targetId)) ?>">Cancel</a><?php endif; ?>
        </div>
      </form>
    <?php endif; ?>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
