<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$id   = (int) ($_GET['id'] ?? 0);
$prof = null;
if ($id > 0) {
    try {
        $prof = row('SELECT id, full_name, email, role, bio, skills_tags, availability_schedule, payment_methods, profile_status, profile_note, profile_note_theme, date_of_birth, is_minor, consent_status, account_status, created_at, wallet, premium_until, profile_frame, profile_accent, profile_layout, profile_progress_style, profile_stat_visibility, avatar_file FROM users WHERE id = ?', [$id]);
    } catch (Throwable $e) {
        /* DB not installed yet */
    }
}

if (!$prof) {
    $pageTitle = 'Profile not found';
    require __DIR__ . '/includes/header.php';
    echo '<section class="section"><div class="container"><div class="card empty-state">'
        . '<div class="es-ic">' . ui_icon('search') . '</div><b>Profile not found</b>'
        . '<p class="muted">No student matches that id.</p>'
        . '<a class="btn btn-primary" href="' . e(base_url('browse.php')) . '">Back to browse</a>'
        . '</div></div></section>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$rating  = seller_rating($id);
$jobs    = $prof['account_status'] === 'verified' ? seller_jobs_done($id) : 0;
$reviewCount = (int) (scalar('SELECT COUNT(*) FROM reviews WHERE reviewee_id = ?', [$id]) ?? 0);
$reviews = rows('SELECT r.*, u.full_name, u.profile_frame, u.profile_accent FROM reviews r JOIN users u ON u.id = r.reviewer_id WHERE r.reviewee_id = ? ORDER BY r.id DESC LIMIT 10', [$id]);
$services = rows(
    'SELECT s.id, s.title, s.price, s.category, s.delivery_days,
            COALESCE((SELECT COUNT(*) FROM orders o WHERE o.service_id = s.id AND o.status = "completed"), 0) AS completed_sales,
            COALESCE((SELECT ROUND(AVG(r.rating), 1) FROM reviews r JOIN orders ro ON ro.id = r.order_id WHERE ro.service_id = s.id), 0) AS service_rating
     FROM services s
     WHERE s.seller_id = ? AND s.status = "active"
     ORDER BY completed_sales DESC, service_rating DESC, s.id DESC',
    [$id]
);
$profPremium = is_premium($prof);
$profileTags = json_decode((string) ($prof['skills_tags'] ?? '[]'), true);
$profileTags = is_array($profileTags) ? array_values(array_filter(array_map('strval', $profileTags))) : [];
$profileAvailability = json_decode((string) ($prof['availability_schedule'] ?? '[]'), true);
$profileAvailability = is_array($profileAvailability) ? array_values(array_intersect(array_map('strval', $profileAvailability), ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'])) : [];
$profilePayments = json_decode((string) ($prof['payment_methods'] ?? '[]'), true);
$profilePayments = is_array($profilePayments) ? array_values(array_intersect(array_map('strval', $profilePayments), ['GCash','Maya','Cash'])) : [];

$me      = get_user();
$isOwner = $me !== null && (int) $me['id'] === (int) $id;
$profileChecks = [
    'full_name' => trim((string) ($prof['full_name'] ?? '')) !== '',
    'email'     => filter_var((string) ($prof['email'] ?? ''), FILTER_VALIDATE_EMAIL) !== false,
    'bio'       => trim((string) ($prof['bio'] ?? '')) !== '',
    'birthday'  => !empty($prof['date_of_birth']),
    'photo'     => !empty($prof['avatar_file']),
];
$profileCompleted = count(array_filter($profileChecks));
$profilePercent = (int) round(($profileCompleted / count($profileChecks)) * 100);

/* Save profile customization (owner only) */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['customize'] ?? '') === '1') {
    if (!$isOwner) {
        redirect('profile.php?id=' . $id);
    }
    if (!hash_equals(csrf_token(), (string) ($_POST['csrf'] ?? ''))) {
        flash('bad', 'Session expired — please try again.');
        redirect('profile.php?id=' . $id);
    }
    $do = (string) ($_POST['do'] ?? 'style');

    if ($do === 'account') {
        $bio = trim((string) ($_POST['bio'] ?? ''));
        $profileStatus = (string) ($_POST['profile_status'] ?? 'online');
        $profileNote = trim((string) ($_POST['profile_note'] ?? ''));
        $noteTheme = (string) ($_POST['profile_note_theme'] ?? 'indigo');
        $tags = array_values(array_unique(array_filter(array_map(static fn($v): string => trim((string) $v), preg_split('/[,\\n]+/', (string) ($_POST['skills_tags'] ?? ''))))));
        $tags = array_slice(array_filter($tags, static fn(string $tag): bool => mb_strlen($tag) <= 30), 0, 12);
        $availability = is_array($_POST['availability'] ?? null) ? array_values(array_intersect(array_map('strval', $_POST['availability']), ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'])) : [];
        $paymentMethods = is_array($_POST['payment_methods'] ?? null) ? array_values(array_intersect(array_map('strval', $_POST['payment_methods']), ['GCash','Maya','Cash'])) : [];
        if (!array_key_exists($profileStatus, profile_statuses())) {
            $profileStatus = 'online';
        }
        $email = strtolower(trim((string) ($_POST['email'] ?? '')));
        $currentPassword = (string) ($_POST['current_password'] ?? '');
        $newPassword = (string) ($_POST['new_password'] ?? '');
        $confirmPassword = (string) ($_POST['confirm_password'] ?? '');
        $account = row('SELECT email, password_hash FROM users WHERE id = ?', [$me['id']]);
        $originalEmail = strtolower((string) ($account['email'] ?? $me['email']));
        if ($bio !== '' && mb_strlen($bio) > 500) {
            flash('bad', 'Keep your description under 500 characters.');
            redirect('profile.php?id=' . $id . '#profile-account');
        }
        if (mb_strlen($profileNote) > 160) {
            flash('bad', 'Keep your profile note under 160 characters.');
            redirect('profile.php?id=' . $id . '#profile-account');
        }
        if (!array_key_exists($noteTheme, profile_note_themes()) || !is_premium($me)) {
            $noteTheme = 'indigo';
        }
        $changingLogin = $email !== (string) $me['email'] || $newPassword !== '';
        if ($changingLogin && !password_verify($currentPassword, (string) ($account['password_hash'] ?? ''))) {
            flash('bad', 'Enter your current password to change login details.');
            redirect('profile.php?id=' . $id . '#profile-account');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('bad', 'Please enter a valid email address.');
            redirect('profile.php?id=' . $id . '#profile-account');
        }
        $existingEmail = row('SELECT id FROM users WHERE email = ? AND id <> ?', [$email, $me['id']]);
        if ($existingEmail) {
            flash('bad', 'That email address is already in use.');
            redirect('profile.php?id=' . $id . '#profile-account');
        }
        if ($newPassword !== '' && (strlen($newPassword) < 8 || $newPassword !== $confirmPassword)) {
            flash('bad', 'New passwords must match and contain at least 8 characters.');
            redirect('profile.php?id=' . $id . '#profile-account');
        }
        if ($newPassword !== '') {
            q('UPDATE users SET bio = ?, skills_tags = ?, availability_schedule = ?, payment_methods = ?, email = ?, profile_status = ?, profile_note = ?, profile_note_theme = ?, password_hash = ? WHERE id = ?', [$bio, json_encode($tags), json_encode($availability), json_encode($paymentMethods), $email, $profileStatus, $profileNote !== '' ? $profileNote : null, $noteTheme, password_hash($newPassword, PASSWORD_DEFAULT), $me['id']]);
        } else {
            q('UPDATE users SET bio = ?, skills_tags = ?, availability_schedule = ?, payment_methods = ?, email = ?, profile_status = ?, profile_note = ?, profile_note_theme = ? WHERE id = ?', [$bio, json_encode($tags), json_encode($availability), json_encode($paymentMethods), $email, $profileStatus, $profileNote !== '' ? $profileNote : null, $noteTheme, $me['id']]);
        }
        $alertFailures = [];
        if ($email !== $originalEmail) {
            $alert = send_security_alert_email(
                $originalEmail,
                'Your Nerasky email address was changed',
                'The email address on your Nerasky account was changed. The new address is ' . $email . '.'
            );
            if (!$alert['ok']) {
                $alertFailures[] = 'email change';
            }
        }
        if ($newPassword !== '') {
            $alert = send_security_alert_email(
                $originalEmail,
                'Your Nerasky password was changed',
                'The password for your Nerasky account was changed.'
            );
            if (!$alert['ok']) {
                $alertFailures[] = 'password change';
            }
        }
        flash('ok', 'Account and profile details updated.');
        if ($alertFailures !== []) {
            flash('warn', 'Your account was updated, but the security alert for your ' . implode(' and ', $alertFailures) . ' could not be emailed. Contact support if this was unexpected.');
        }
        redirect('profile.php?id=' . $id . '#profile-account');
    }

    if ($do === 'remove') {
        $old = avatar_file_for((int) $me['id']);
        if ($old && is_file(__DIR__ . '/uploads/avatars/' . $old)) {
            @unlink(__DIR__ . '/uploads/avatars/' . $old);
        }
        q('UPDATE users SET avatar_file = NULL WHERE id = ?', [$me['id']]);
        flash('ok', 'Profile photo removed — back to the classic initials.');
        redirect('profile.php?id=' . $id);
    }

    if ($do === 'photo') {
        $f = $_FILES['avatar'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            flash('bad', 'Choose an image file first.');
            redirect('profile.php?id=' . $id);
        }
        if ((int) $f['size'] > 3 * 1024 * 1024) {
            flash('bad', 'Photo is too large — keep it under 3 MB.');
            redirect('profile.php?id=' . $id);
        }
        $ext = strtolower(pathinfo((string) $f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true) || !@getimagesize((string) $f['tmp_name'])) {
            flash('bad', 'Only JPG, PNG, WebP or GIF images are allowed.');
            redirect('profile.php?id=' . $id);
        }
        if (!is_dir(__DIR__ . '/uploads/avatars')) {
            @mkdir(__DIR__ . '/uploads/avatars', 0775, true);
        }
        $name = 'av_' . bin2hex(random_bytes(6)) . '.' . $ext;
        if (!@move_uploaded_file((string) $f['tmp_name'], __DIR__ . '/uploads/avatars/' . $name)) {
            flash('bad', 'Could not save the photo — try again.');
            redirect('profile.php?id=' . $id);
        }
        $old = avatar_file_for((int) $me['id']);
        if ($old && is_file(__DIR__ . '/uploads/avatars/' . $old)) {
            @unlink(__DIR__ . '/uploads/avatars/' . $old);
        }
        q('UPDATE users SET avatar_file = ? WHERE id = ?', [$name, $me['id']]);
        flash('ok', 'New profile photo saved — looking good!');
        redirect('profile.php?id=' . $id);
    }

    $frame  = (string) ($_POST['frame'] ?? 'none');
    $accent = (string) ($_POST['accent'] ?? 'indigo');
    $layout = (string) ($_POST['layout'] ?? 'classic');
    $progressStyle = (string) ($_POST['progress_style'] ?? 'gradient');
    $selectedStats = is_array($_POST['stats'] ?? null) ? array_map('strval', $_POST['stats']) : [];
    $allowedStats = ['seller_orders', 'seller_earnings', 'seller_reviews', 'seller_rating', 'buyer_orders', 'buyer_spent', 'buyer_active'];
    $frames = profile_frames();
    $layouts = profile_layouts();
    if (!isset($frames[$frame])) {
        $frame = 'none';
    }
    if (!array_key_exists($accent, profile_accents())) {
        $accent = 'indigo';
    }
    if (!isset($layouts[$layout])) {
        $layout = 'classic';
    }
    if (!in_array($progressStyle, ['gradient', 'solid', 'sunset'], true)) {
        $progressStyle = 'gradient';
    }
    if ($progressStyle !== 'gradient' && !is_premium($me)) {
        flash('warn', 'Custom progress bar styles are part of Nerasky Pro.');
        redirect('profile.php?id=' . $id);
    }
    if (!is_premium($me)) {
        $selectedStats = $allowedStats;
    } else {
        $selectedStats = array_values(array_intersect($selectedStats, $allowedStats));
        if ($selectedStats === []) {
            $selectedStats = $allowedStats;
        }
    }
    if ($frames[$frame]['premium'] && !is_premium($me)) {
        flash('warn', 'That frame is part of Nerasky Pro — subscribe to unlock it.');
        redirect('profile.php?id=' . $id);
    }
    if ($layouts[$layout]['premium'] && !is_premium($me)) {
        flash('warn', 'That profile layout is part of Nerasky Pro — subscribe to unlock it.');
        redirect('profile.php?id=' . $id);
    }
    q('UPDATE users SET profile_frame = ?, profile_accent = ?, profile_layout = ?, profile_progress_style = ?, profile_stat_visibility = ? WHERE id = ?', [$frame, $accent, $layout, $progressStyle, json_encode($selectedStats), $me['id']]);
    flash('ok', 'Profile customization saved — looking sharp!');
    redirect('profile.php?id=' . $id);
}

/* Profiles are for members — guests are redirected to log in */
if (hide_names()) {
    flash('warn', 'Log in to view student profiles.');
    redirect('login.php');
}

$boughtDone = (int) (row('SELECT COUNT(*) AS n FROM orders WHERE buyer_id = ? AND status = "completed"', [$id])['n'] ?? 0);
$buyerSpent = (float) (scalar('SELECT COALESCE(SUM(price), 0) FROM orders WHERE buyer_id = ? AND status = "completed"', [$id]) ?? 0);
$buyerActive = (int) (scalar('SELECT COUNT(*) FROM orders WHERE buyer_id = ? AND status IN ("awaiting_payment","in_progress","delivered")', [$id]) ?? 0);
$defaultStats = ['seller_orders', 'seller_earnings', 'seller_reviews', 'seller_rating', 'buyer_orders', 'buyer_spent', 'buyer_active'];
$visibleStats = $defaultStats;
if ($profPremium && !empty($prof['profile_stat_visibility'])) {
    $savedStats = json_decode((string) $prof['profile_stat_visibility'], true);
    if (is_array($savedStats)) {
        $visibleStats = array_values(array_intersect(array_map('strval', $savedStats), $defaultStats)) ?: $defaultStats;
    }
}
$sellerStats = null;
if ($prof['account_status'] === 'verified') {
    $sellerStats = row(
        'SELECT COUNT(*) AS completed_orders,
                COALESCE(SUM(seller_payout), 0) AS total_earned,
                MAX(completed_at) AS last_completed
         FROM orders
         WHERE seller_id = ? AND status = "completed"',
        [$id]
    ) ?: ['completed_orders' => 0, 'total_earned' => 0, 'last_completed' => null];
    $sellerReviewCount = (int) (scalar('SELECT COUNT(*) FROM reviews WHERE reviewee_id = ?', [$id]) ?? 0);
    $completedOrders = (int) $sellerStats['completed_orders'];
    $nextMilestone = $completedOrders < 10 ? 10 : ($completedOrders < 25 ? 25 : ($completedOrders < 50 ? 50 : $completedOrders + 25));
    $progressPercent = $nextMilestone > 0 ? min(100, (int) round(($completedOrders / $nextMilestone) * 100)) : 0;
    $sellerLevel = $completedOrders >= 50 ? 'Top seller' : ($completedOrders >= 25 ? 'Trusted seller' : ($completedOrders >= 10 ? 'Rising seller' : ($profPremium ? 'New Pro seller' : 'New seller')));
    $bestService = $services[0] ?? null;
}
$buyerMilestone = $boughtDone < 5 ? 5 : ($boughtDone < 10 ? 10 : ($boughtDone < 25 ? 25 : $boughtDone + 25));
$buyerProgressPercent = $buyerMilestone > 0 ? min(100, (int) round(($boughtDone / $buyerMilestone) * 100)) : 0;

$pageTitle = hide_names() ? 'Student profile' : $prof['full_name'];
$bodyClass = 'page-profile';
require __DIR__ . '/includes/header.php';
?>

<section class="section-tight">
  <div class="container">
    <div class="profile-hero profile-layout-<?= e((string) ($prof['profile_layout'] ?? 'classic')) ?> reveal<?= $profPremium ? ' pro' : '' ?>" style="<?= profile_style_attr($prof) ?>">
      <?= avatar_of($prof, 84) ?>
      <div class="profile-copy" style="flex:1">
        <div class="flex gap-2">
          <h1 style="margin:0"><?= e(member_name($prof)) ?></h1>
          <?php if ($profPremium): ?><?= premium_badge('lg') ?><?php endif; ?>
          <?php if ($prof['account_status'] !== 'verified'): ?><span class="pill pill-warn">Pending verification</span><?php else: ?><span class="pill pill-ok"><span class="dot"></span>Verified student</span><?php endif; ?>
          <?php if (get_user() && (int) get_user()['id'] !== (int) $id && $prof['account_status'] === 'verified'): ?>
            <a class="btn btn-white btn-sm" href="<?= e(base_url('messages.php?to=' . $id)) ?>"><?= ui_icon('chat') ?> Message</a>
          <?php endif; ?>
        </div>
        <div class="ph-meta">
          Joined <?= date('F Y', strtotime((string) $prof['created_at'])) ?><?= !empty($prof['date_of_birth']) ? ' · ' . (new DateTimeImmutable((string) $prof['date_of_birth']))->diff(new DateTimeImmutable('today'))->y . ' years old' : '' ?>
          <?php if ($prof['is_minor'] === '1' || $prof['is_minor'] === 1): ?> · Minor (approved consent)<?php endif; ?>
          <?php if ($profPremium): ?> · <b style="color:#fbbf24">Nerasky Pro</b><?php endif; ?>
        </div>
        <div class="profile-share-row">
          <button type="button" class="btn btn-white btn-sm" data-share-profile="<?= e(base_url('profile.php?id=' . $id)) ?>"><?= ui_icon('share', 15) ?> Share profile</button>
          <?php if ($me !== null && !$isOwner && ($prof['role'] ?? 'user') !== 'admin'): ?>
            <a class="btn btn-white btn-sm" href="<?= e(base_url('report.php?type=user&id=' . $id)) ?>"><?= ui_icon('flag', 15) ?> Report user</a>
          <?php endif; ?>
          <span class="profile-share-status" aria-live="polite"></span>
        </div>
        <?php if ($rating !== null): ?>
          <div class="mt-1" style="display:flex;align-items:center;gap:.6rem">
            <?= star_row($rating) ?>
            <b style="color:#fff"><?= number_format($rating, 1) ?></b>
            <span class="muted" style="color:#8b93b8;font-size:var(--fs-xs)"><?= $reviewCount ?> review<?= $reviewCount === 1 ? '' : 's' ?></span>
          </div>
        <?php endif; ?>
      </div>
      <div class="profile-stats hidden-mob" style="text-align:right">
        <div style="display:flex;gap:1.8rem;justify-content:flex-end">
          <div>
            <div style="font-size:1.6rem;font-weight:800;color:#fff"><?= $jobs ?></div>
            <div class="muted" style="color:#8b93b8;font-size:var(--fs-xs);text-transform:uppercase;letter-spacing:.07em">jobs completed</div>
          </div>
          <div>
            <div style="font-size:1.6rem;font-weight:800;color:#fff"><?= $boughtDone ?></div>
            <div class="muted" style="color:#8b93b8;font-size:var(--fs-xs);text-transform:uppercase;letter-spacing:.07em">orders placed</div>
          </div>
        </div>
      </div>
    </div>

    <?php if ($isOwner): ?>
    <div class="card card-pad reveal reveal-delay-1" style="margin-top:1.2rem">
      <div class="flex-between" style="gap:1rem;align-items:flex-start">
        <div>
          <span class="eyebrow" style="margin-bottom:.35rem">Profile completion</span>
          <h3 style="font-size:1.1rem;margin-bottom:.2rem"><?= $profilePercent ?>% complete</h3>
          <p class="muted" style="font-size:var(--fs-sm);margin:0"><?= $profileCompleted === count($profileChecks) ? 'Your profile is ready for students to discover.' : 'Complete a few details to help students know who they are working with.' ?></p>
        </div>
        <b style="font-size:1.2rem;color:var(--brand-600)"><?= $profileCompleted ?>/<?= count($profileChecks) ?></b>
      </div>
      <div class="seller-progress progress-fill-gradient" role="progressbar" aria-label="Profile completion" aria-valuenow="<?= $profilePercent ?>" aria-valuemin="0" aria-valuemax="100" style="margin-top:.8rem">
        <span style="width:<?= $profilePercent ?>%;min-width:<?= $profilePercent > 0 ? '6px' : '0' ?>"></span>
      </div>
      <?php if ($profileCompleted < count($profileChecks)): ?>
        <small class="muted" style="display:block;margin-top:.55rem">Missing: <?= e(implode(', ', array_map(static fn(string $key): string => ['full_name' => 'your name', 'email' => 'email', 'bio' => 'a short bio', 'birthday' => 'date of birth', 'photo' => 'a profile photo'][$key], array_keys(array_filter($profileChecks, static fn(bool $done): bool => !$done))))) ?>. <a href="#profile-account">Update your details →</a></small>
      <?php endif; ?>
    </div>
    <div class="profile-customizer-toggle reveal reveal-delay-1">
      <div>
        <b><?= ui_icon('palette', 16) ?> Profile customization</b>
        <small class="muted">Keep your profile clean, or open the editor when you want to make changes.</small>
      </div>
      <button class="btn btn-primary btn-sm" type="button" id="custToggle" aria-expanded="false" aria-controls="custPanel"><?= ui_icon('palette', 15) ?> Show customize profile</button>
    </div>
    <form method="post" enctype="multipart/form-data" class="card card-pad reveal reveal-delay-1 profile-customizer" id="custPanel" hidden style="margin-top:1.2rem"
          data-frame="<?= e((string) $prof['profile_frame']) ?>" data-accent="<?= e((string) $prof['profile_accent']) ?>" data-layout="<?= e((string) ($prof['profile_layout'] ?? 'classic')) ?>"
          data-pro="<?= $profPremium ? '1' : '0' ?>" data-accents="<?= e((string) json_encode(profile_accents())) ?>">
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="customize" value="1">
      <div class="flex-between mb-1" style="flex-wrap:wrap;gap:.5rem">
        <div>
          <h3 style="font-size:1.05rem;margin:0"><?= ui_icon('palette') ?> Customize your profile</h3>
          <span class="muted" style="font-size:var(--fs-xs)">Your frame and accent show everywhere your avatar appears</span>
        </div>
        <button class="btn btn-ghost btn-sm" type="button" id="custHide"><?= ui_icon('x', 15) ?> Hide editor</button>
      </div>
      <nav class="customizer-tabs" aria-label="Profile customization sections">
        <button type="button" class="customizer-tab active" data-customizer-tab="appearance"><?= ui_icon('palette', 15) ?> Appearance</button>
        <button type="button" class="customizer-tab" data-customizer-tab="stats"><?= ui_icon('trending', 15) ?> Progress stats</button>
        <button type="button" class="customizer-tab" data-customizer-tab="account"><?= ui_icon('users', 15) ?> Account details</button>
      </nav>
      <div class="customizer-tab-panel active" data-customizer-panel="appearance">
      <div class="customizer-layout" style="display:flex;gap:1.6rem;align-items:flex-start;flex-wrap:wrap">
        <div class="customizer-preview" style="text-align:center;padding:1rem 1.2rem;background:var(--surface-2);border-radius:16px">
          <span class="avwrap avf-<?= e((string) $prof['profile_frame']) ?>" id="custPrev" style="--avs:76px;--avc:<?= e(profile_accent_hex((string) $prof['profile_accent'])) ?>"><?= avatar_html($prof['full_name'], 76, avatar_file_for((int) $prof['id'])) ?></span>
          <small class="muted" style="display:block;margin-top:.6rem;font-size:var(--fs-xs)">Live preview</small>
        </div>
        <div class="customizer-fields" style="flex:1;min-width:260px">
          <div class="customizer-block">
          <div class="customizer-block-title"><span class="customizer-step">01</span><span><b>Identity</b><small>Set your photo, frame, and accent</small></span></div>
          <label style="font-weight:700;font-size:var(--fs-xs);text-transform:uppercase;letter-spacing:.06em;color:var(--muted);display:block;margin-bottom:.55rem">Profile photo</label>
          <div class="cust-photo">
            <input type="file" name="avatar" id="avatarInput" accept="image/png,image/jpeg,image/webp,image/gif">
            <div class="flex" style="gap:.6rem;margin-top:.6rem">
              <button class="btn btn-primary" name="do" value="photo"><?= ui_icon('plus') ?> Upload photo</button>
              <button class="btn" name="do" value="remove" <?= avatar_file_for((int) $prof['id']) ? '' : 'disabled' ?>>Remove</button>
            </div>
          </div>
          <small class="muted" style="display:block;margin-top:.4rem;font-size:var(--fs-xs)">JPG, PNG, WebP or GIF · up to 3 MB · shown everywhere your avatar appears</small>
          <label style="font-weight:700;font-size:var(--fs-xs);text-transform:uppercase;letter-spacing:.06em;color:var(--muted);display:block;margin:1.1rem 0 .55rem">Border frame</label>
          <div class="cust-grid">
            <?php foreach (profile_frames() as $fkey => $f): $locked = $f['premium'] && !$profPremium; ?>
              <div class="frame-swatch<?= $locked ? ' locked' : '' ?><?= (string) $prof['profile_frame'] === $fkey ? ' sel' : '' ?>" data-frame="<?= e($fkey) ?>">
                <input type="radio" name="frame" value="<?= e($fkey) ?>" <?= $locked ? 'disabled' : '' ?> <?= (string) $prof['profile_frame'] === $fkey ? 'checked' : '' ?>>
                <span class="avwrap avf-<?= e($fkey) ?>" style="--avs:44px;--avc:<?= e(profile_accent_hex((string) $prof['profile_accent'])) ?>"><?= avatar_html($prof['full_name'], 44) ?></span>
                <small><?= e($f['label']) ?></small>
                <?php if ($f['premium']): ?><span class="pro-badge swatch-pro">★ Pro</span><?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
          <label style="font-weight:700;font-size:var(--fs-xs);text-transform:uppercase;letter-spacing:.06em;color:var(--muted);display:block;margin:1.1rem 0 .55rem">Accent colour</label>
          <div class="flex" style="gap:.6rem;flex-wrap:wrap">
            <?php foreach (profile_accents() as $akey => $hex): ?>
              <label class="accent-dot<?= (string) $prof['profile_accent'] === $akey ? ' sel' : '' ?>" style="background:<?= e($hex) ?>" data-accent="<?= e($akey) ?>">
                <input type="radio" name="accent" value="<?= e($akey) ?>" <?= (string) $prof['profile_accent'] === $akey ? 'checked' : '' ?>>
              </label>
            <?php endforeach; ?>
          </div>
          </div>
          <div class="customizer-block">
          <div class="customizer-block-title"><span class="customizer-step">02</span><span><b>Profile style</b><small>Choose your layout and progress look</small></span></div>
          <label style="font-weight:700;font-size:var(--fs-xs);text-transform:uppercase;letter-spacing:.06em;color:var(--muted);display:block;margin:1.1rem 0 .55rem">Profile layout</label>
          <div class="layout-options">
            <?php foreach (profile_layouts() as $lkey => $layoutOption): $locked = $layoutOption['premium'] && !$profPremium; ?>
              <label class="layout-option<?= $locked ? ' locked' : '' ?><?= (string) ($prof['profile_layout'] ?? 'classic') === $lkey ? ' sel' : '' ?>">
                <input type="radio" name="layout" value="<?= e($lkey) ?>" <?= $locked ? 'disabled' : '' ?> <?= (string) ($prof['profile_layout'] ?? 'classic') === $lkey ? 'checked' : '' ?>>
                <span><b><?= e($layoutOption['label']) ?></b><small><?= e($layoutOption['description']) ?></small></span>
                <?php if ($layoutOption['premium']): ?><em class="pro-badge">★ Pro</em><?php endif; ?>
              </label>
            <?php endforeach; ?>
          </div>
          <label style="font-weight:700;font-size:var(--fs-xs);text-transform:uppercase;letter-spacing:.06em;color:var(--muted);display:block;margin:1.1rem 0 .55rem">Progress bar style</label>
          <div class="progress-style-options">
            <?php foreach (['gradient' => 'Gradient', 'solid' => 'Solid', 'sunset' => 'Sunset'] as $styleKey => $styleLabel): $locked = !$profPremium && $styleKey !== 'gradient'; ?>
              <label class="progress-style-option<?= $locked ? ' locked' : '' ?><?= (string) ($prof['profile_progress_style'] ?? 'gradient') === $styleKey ? ' sel' : '' ?>">
                <input type="radio" name="progress_style" value="<?= e($styleKey) ?>" <?= $locked ? 'disabled' : '' ?> <?= (string) ($prof['profile_progress_style'] ?? 'gradient') === $styleKey ? 'checked' : '' ?>>
                <span class="progress-style-swatch progress-style-<?= e($styleKey) ?>"></span><b><?= e($styleLabel) ?></b>
                <?php if ($locked): ?><em class="pro-badge">★ Pro</em><?php endif; ?>
              </label>
            <?php endforeach; ?>
          </div>
          </div>
          <div class="cust-upsell banner banner-info" style="margin-top:1.1rem">
            <span class="b-ic"><?= ui_icon('sparkle') ?></span><span><b>Pro unlocks premium frames, layouts, progress styles, and stats.</b> <a href="<?= e(base_url('premium.php')) ?>" style="font-weight:700">Unlock Nerasky Pro →</a></span>
          </div>
          <button class="btn btn-primary" style="margin-top:1rem"><?= ui_icon('check') ?> Save customization</button>
        </div>
      </div>
      </div>
      <div class="customizer-tab-panel" data-customizer-panel="stats">
        <div id="profile-stat-settings" class="profile-stat-settings stats-panel-card">
          <div class="customizer-block-title"><span class="customizer-step">01</span><span><b>Public progress stats</b><small>Choose the progress bars visitors can see</small></span></div>
          <div class="stat-setting-group">
            <b>Seller progress bars</b>
            <div class="stat-visibility-grid">
              <?php foreach (['seller_orders' => 'Completed orders', 'seller_earnings' => 'Total earnings', 'seller_reviews' => 'Reviews', 'seller_rating' => 'Rating'] as $statKey => $statLabel): $locked = !$profPremium; ?>
                <label class="stat-visibility-option<?= $locked ? ' locked' : '' ?>">
                  <input type="checkbox" name="stats[]" value="<?= e($statKey) ?>" <?= in_array($statKey, $visibleStats, true) ? 'checked' : '' ?> <?= $locked ? 'disabled' : '' ?>>
                  <span><?= e($statLabel) ?></span><?php if ($locked): ?><em class="pro-badge">★ Pro</em><?php endif; ?>
                </label>
              <?php endforeach; ?>
            </div>
          </div>
          <div class="stat-setting-group">
            <b>Buyer progress bars</b>
            <div class="stat-visibility-grid">
              <?php foreach (['buyer_orders' => 'Completed orders', 'buyer_spent' => 'Total spending', 'buyer_active' => 'Active orders'] as $statKey => $statLabel): $locked = !$profPremium; ?>
                <label class="stat-visibility-option<?= $locked ? ' locked' : '' ?>">
                  <input type="checkbox" name="stats[]" value="<?= e($statKey) ?>" <?= in_array($statKey, $visibleStats, true) ? 'checked' : '' ?> <?= $locked ? 'disabled' : '' ?>>
                  <span><?= e($statLabel) ?></span><?php if ($locked): ?><em class="pro-badge">★ Pro</em><?php endif; ?>
                </label>
              <?php endforeach; ?>
            </div>
          </div>
          <small class="muted">Free profiles use the standard progress bars. Pro members can choose which bars are shown.</small>
          <button class="btn btn-primary" style="margin-top:1rem"><?= ui_icon('check') ?> Save progress stats</button>
        </div>
      </div>
      <div class="customizer-tab-panel" data-customizer-panel="account" id="profile-account">
        <div class="account-settings-card">
          <div class="customizer-block-title"><span class="customizer-step">01</span><span><b>Profile information</b><small>Keep your public identity up to date</small></span></div>
          <div class="profile-presence-editor">
            <label class="account-field"><span>Presence</span><select class="input" name="profile_status"><?php foreach (profile_statuses() as $statusKey => $status): ?><option value="<?= e($statusKey) ?>" <?= (string) ($prof['profile_status'] ?? 'online') === $statusKey ? 'selected' : '' ?>><?= e($status['label']) ?></option><?php endforeach; ?></select></label>
            <label class="account-field"><span>Profile note</span><input class="input" name="profile_note" maxlength="160" value="<?= e((string) ($prof['profile_note'] ?? '')) ?>" placeholder="Studying until 6 PM"></label>
            <label class="account-field"><span>Note appearance <?php if (!$profPremium): ?><small class="pro-lock">★ Pro</small><?php endif; ?></span><select class="input" name="profile_note_theme" <?= !$profPremium ? 'disabled' : '' ?>><?php foreach (profile_note_themes() as $themeKey => $theme): ?><option value="<?= e($themeKey) ?>" <?= profile_note_theme_key($prof) === $themeKey ? 'selected' : '' ?>><?= e($theme['label']) ?></option><?php endforeach; ?></select><small><?= $profPremium ? 'Choose the background and accent shown with your public note.' : 'Upgrade to Pro to customize your note colors.' ?></small></label>
          </div>
          <label class="account-field"><span>Description</span><textarea class="input" name="bio" rows="4" maxlength="500" placeholder="Tell students what you offer..."><?= e((string) ($prof['bio'] ?? '')) ?></textarea><small>Up to 500 characters. Your note appears beside your status like Messenger.</small></label>
          <label class="account-field"><span>Skills and tags</span><input class="input" name="skills_tags" maxlength="360" value="<?= e(implode(', ', $profileTags)) ?>" placeholder="Graphic design, tutoring, video editing"><small>Comma-separated tags help students find you.</small></label>
          <div class="profile-preference-grid">
            <fieldset class="account-field"><legend>Availability</legend><div class="preference-options"><?php foreach (['Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $day): ?><label><input type="checkbox" name="availability[]" value="<?= $day ?>" <?= in_array($day, $profileAvailability, true) ? 'checked' : '' ?>> <?= $day ?></label><?php endforeach; ?></div></fieldset>
            <fieldset class="account-field"><legend>Preferred payment methods</legend><div class="preference-options"><?php foreach (['GCash','Maya','Cash'] as $method): ?><label><input type="checkbox" name="payment_methods[]" value="<?= $method ?>" <?= in_array($method, $profilePayments, true) ? 'checked' : '' ?>> <?= $method ?></label><?php endforeach; ?></div></fieldset>
          </div>
          <label class="account-field"><span>Email address</span><input class="input" type="email" name="email" value="<?= e((string) $prof['email']) ?>" autocomplete="email"></label>
          <div class="customizer-block-title account-security-title"><span class="customizer-step">02</span><span><b>Security</b><small>Leave password fields blank to keep your password</small></span></div>
          <label class="account-field"><span>Current password</span><input class="input" type="password" name="current_password" autocomplete="current-password"></label>
          <div class="account-password-grid">
            <label class="account-field"><span>New password</span><input class="input" type="password" name="new_password" minlength="8" autocomplete="new-password"></label>
            <label class="account-field"><span>Confirm new password</span><input class="input" type="password" name="confirm_password" minlength="8" autocomplete="new-password"></label>
          </div>
          <button class="btn btn-primary" name="do" value="account"><?= ui_icon('check') ?> Save account details</button>
        </div>
      </div>
    </form>
    <?php endif; ?>

    <div class="order-summary mt-4">
      <div class="stack">
        <div class="card card-pad">
          <div class="flex-between" style="gap:.7rem;align-items:flex-start"><h3 style="font-size:1rem;margin-bottom:.6rem">About me</h3><?= profile_status_badge($prof) ?></div>
          <?php if (trim((string) ($prof['profile_note'] ?? '')) !== ''): ?><div class="profile-note <?= e(profile_note_theme_class($prof)) ?>"><?= ui_icon('message', 14) ?> <?= e((string) $prof['profile_note']) ?></div><?php endif; ?>
          <p class="muted" style="margin:0"><?= $prof['bio'] ? e($prof['bio']) : e('This student hasn\'t written a bio yet.') ?></p>
          <?php if ($profileTags): ?><div class="profile-tags" aria-label="Skills and tags"><?php foreach ($profileTags as $tag): ?><span>#<?= e($tag) ?></span><?php endforeach; ?></div><?php endif; ?>
          <?php if ($profileAvailability || $profilePayments): ?><div class="profile-preferences"><span><?= ui_icon('clock', 14) ?> <?= $profileAvailability ? 'Available ' . e(implode(', ', $profileAvailability)) : 'Availability not set' ?></span><span><?= ui_icon('card', 14) ?> <?= $profilePayments ? e(implode(' · ', $profilePayments)) : 'Payment preferences not set' ?></span></div><?php endif; ?>
        </div>

        <?php if (count($services) > 0): ?>
          <div>
            <h3 style="font-size:1.1rem">Active services</h3>
            <div class="grid-2 gap-2">
              <?php foreach ($services as $serviceIndex => $sv): ?>
                <div class="card card-hover service-card">
                  <div class="sv-body">
                    <div class="sv-top">
                      <span class="sv-cat"><?= cat_icon((string) $sv['category']) ?> <?= e($sv['category']) ?></span>
                      <span class="sv-delivery"><?= ui_icon('box') ?> <?= (int) $sv['delivery_days'] ?> day<?= (int) $sv['delivery_days'] > 1 ? 's' : '' ?></span>
                    </div>
                    <?php if ($profPremium && $serviceIndex === 0): ?><span class="service-best-label">★ Best seller</span><?php endif; ?>
                    <h3 style="font-size:.98rem"><a href="<?= e(base_url('service.php?id=' . (int) $sv['id'])) ?>"><?= e($sv['title']) ?></a></h3>
                    <div class="flex-between" style="gap:.6rem">
                      <span class="sv-price<?= $me ? '' : ' price-guest-blur' ?>" <?= $me ? '' : 'title="Log in to view the exact price"' ?> style="font-size:1.05rem"><?= e(marketplace_price((float) $sv['price'], $me)) ?></span>
                      <?php if ((int) $sv['completed_sales'] > 0): ?><small class="muted"><?= (int) $sv['completed_sales'] ?> sold</small><?php endif; ?>
                    </div>
                    <?php if ($isOwner): ?><div class="service-owner-actions"><a class="btn btn-ghost btn-sm" href="<?= e(base_url('service-edit.php?id=' . (int) $sv['id'])) ?>"><?= ui_icon('pen', 13) ?> Edit</a><a class="btn btn-ghost btn-sm" href="<?= e(base_url('dashboard.php')) ?>">Manage services</a></div><?php endif; ?>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endif; ?>

        <?php if ($sellerStats !== null): ?>
          <div class="card card-pad <?= $profPremium ? 'pro-performance' : 'profile-progress-card' ?>">
            <div class="flex-between" style="gap:1rem;align-items:flex-start">
              <div>
                <span class="eyebrow" style="margin-bottom:.45rem"><?= $profPremium ? 'Pro seller dashboard' : 'Seller progress dashboard' ?></span>
                <h3 style="font-size:1.15rem;margin-bottom:.2rem"><?= e($sellerLevel) ?></h3>
                <p class="muted" style="font-size:var(--fs-sm);margin:0">A public progress bar based on completed orders and marketplace activity.</p>
              </div>
              <div class="profile-card-actions"><?php if ($isOwner): ?><a class="profile-settings-link" href="#profile-stat-settings" title="Change seller stats"><?= ui_icon('settings', 15) ?> <span>Stats</span></a><?php endif; ?><?php if ($profPremium): ?><?= premium_badge() ?><?php endif; ?></div>
            </div>
            <div class="seller-progress-wrap">
              <div class="flex-between" style="font-size:var(--fs-sm);margin-bottom:.45rem">
                <b><?= $completedOrders ?> of <?= $nextMilestone ?> completed orders</b>
                <span class="muted"><?= $progressPercent ?>%</span>
              </div>
              <div class="seller-progress progress-fill-<?= e((string) ($prof['profile_progress_style'] ?? 'gradient')) ?>" role="progressbar" aria-label="Completed orders progress" aria-valuenow="<?= $completedOrders ?>" aria-valuemin="0" aria-valuemax="<?= $nextMilestone ?>">
                <span style="width:<?= $progressPercent ?>%;min-width:<?= $completedOrders > 0 ? '6px' : '0' ?>"></span>
              </div>
              <small class="muted"><?= $completedOrders < $nextMilestone ? ($nextMilestone - $completedOrders) . ' more completed order' . ($nextMilestone - $completedOrders === 1 ? '' : 's') . ' to the next seller milestone.' : 'Milestone reached — keep building your reputation.' ?></small>
            </div>
            <div class="profile-stat-grid progress-fill-<?= e((string) ($prof['profile_progress_style'] ?? 'gradient')) ?>">
              <?php if (in_array('seller_orders', $visibleStats, true)): ?>
                <div class="profile-stat"><div class="profile-stat-head"><small>Completed orders</small><b><?= $completedOrders ?></b></div><div class="stat-track"><i style="width:<?= $progressPercent ?>%"></i></div><span class="stat-progress-caption"><?= $progressPercent ?>% to next level</span></div>
              <?php endif; ?>
              <?php if (in_array('seller_earnings', $visibleStats, true)): $earningsPercent = min(100, (int) round(((float) $sellerStats['total_earned'] / 5000) * 100)); ?>
                <div class="profile-stat"><div class="profile-stat-head"><small>Total earnings</small><b><?= money((float) $sellerStats['total_earned']) ?></b></div><div class="stat-track"><i style="width:<?= $earningsPercent ?>%"></i></div><span class="stat-progress-caption"><?= $earningsPercent ?>% milestone progress</span></div>
              <?php endif; ?>
              <?php if (in_array('seller_reviews', $visibleStats, true)): $reviewsPercent = min(100, $sellerReviewCount * 4); ?>
                <div class="profile-stat"><div class="profile-stat-head"><small>Reviews received</small><b><?= $sellerReviewCount ?></b></div><div class="stat-track"><i style="width:<?= $reviewsPercent ?>%"></i></div><span class="stat-progress-caption"><?= $reviewsPercent ?>% trust progress</span></div>
              <?php endif; ?>
              <?php if (in_array('seller_rating', $visibleStats, true)): $ratingPercent = $rating !== null ? min(100, (int) round(((float) $rating / 5) * 100)) : 0; ?>
                <div class="profile-stat"><div class="profile-stat-head"><small>Average rating</small><b><?= $rating !== null ? number_format($rating, 1) . '/5' : '—' ?></b></div><div class="stat-track"><i style="width:<?= $ratingPercent ?>%"></i></div><span class="stat-progress-caption"><?= $ratingPercent ?>% reputation progress</span></div>
              <?php endif; ?>
            </div>
            <?php if (!$profPremium): ?><div class="profile-progress-note">★ Pro members can choose which progress stats appear and unlock advanced profile styles.</div><?php endif; ?>
            <?php if ($profPremium && $bestService !== null): ?>
              <a class="best-service" href="<?= e(base_url('service.php?id=' . (int) $bestService['id'])) ?>">
                <span class="best-service-icon"><?= ui_icon('sparkle', 18) ?></span>
                <span class="best-service-copy">
                  <small>Best-performing service</small>
                  <b><?= e($bestService['title']) ?></b>
                  <span><?= (int) $bestService['completed_sales'] ?> completed sale<?= (int) $bestService['completed_sales'] === 1 ? '' : 's' ?> · <span class="<?= $me ? '' : 'price-guest-blur' ?>" <?= $me ? '' : 'title="Log in to view the exact price"' ?>><?= e(marketplace_price((float) $bestService['price'], $me)) ?></span></span>
                </span>
                <span class="best-service-arrow">→</span>
              </a>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <?php if ($prof['account_status'] === 'verified'): ?>
          <div class="card card-pad profile-progress-card buyer-progress-card">
            <div class="flex-between" style="gap:1rem;align-items:flex-start">
              <div>
                <span class="eyebrow" style="margin-bottom:.45rem">Buyer level & progress</span>
                <h3 style="font-size:1.15rem;margin-bottom:.2rem">Community buyer</h3>
                <p class="muted" style="font-size:var(--fs-sm);margin:0">Completed orders show your experience in the community.</p>
              </div>
              <div class="profile-card-actions"><?php if ($isOwner): ?><a class="profile-settings-link" href="#profile-stat-settings" title="Change buyer stats"><?= ui_icon('settings', 15) ?> <span>Stats</span></a><?php endif; ?><?php if ($profPremium): ?><?= premium_badge() ?><?php endif; ?></div>
            </div>
            <div class="seller-progress-wrap">
              <div class="flex-between" style="font-size:var(--fs-sm);margin-bottom:.45rem">
                <b><?= $boughtDone ?> of <?= $buyerMilestone ?> completed orders</b>
                <span class="muted"><?= $buyerProgressPercent ?>%</span>
              </div>
              <div class="seller-progress buyer-progress progress-fill-<?= e((string) ($prof['profile_progress_style'] ?? 'gradient')) ?>" role="progressbar" aria-label="Completed buyer orders progress" aria-valuenow="<?= $boughtDone ?>" aria-valuemin="0" aria-valuemax="<?= $buyerMilestone ?>">
                <span style="width:<?= $buyerProgressPercent ?>%;min-width:<?= $boughtDone > 0 ? '6px' : '0' ?>"></span>
              </div>
              <small class="muted"><?= $boughtDone < $buyerMilestone ? ($buyerMilestone - $boughtDone) . ' more completed order' . ($buyerMilestone - $boughtDone === 1 ? '' : 's') . ' to the next buyer milestone.' : 'Milestone reached — keep exploring.' ?></small>
            </div>
            <div class="profile-stat-grid progress-fill-<?= e((string) ($prof['profile_progress_style'] ?? 'gradient')) ?>">
              <?php if (in_array('buyer_orders', $visibleStats, true)): ?>
                <div class="profile-stat"><div class="profile-stat-head"><small>Completed orders</small><b><?= $boughtDone ?></b></div><div class="stat-track"><i style="width:<?= $buyerProgressPercent ?>%"></i></div><span class="stat-progress-caption"><?= $buyerProgressPercent ?>% to next level</span></div>
              <?php endif; ?>
              <?php if (in_array('buyer_spent', $visibleStats, true)): $spentPercent = min(100, (int) round(($buyerSpent / 5000) * 100)); ?>
                <div class="profile-stat"><div class="profile-stat-head"><small>Total spending</small><b><?= money($buyerSpent) ?></b></div><div class="stat-track"><i style="width:<?= $spentPercent ?>%"></i></div><span class="stat-progress-caption"><?= $spentPercent ?>% activity progress</span></div>
              <?php endif; ?>
              <?php if (in_array('buyer_active', $visibleStats, true)): $activePercent = min(100, $buyerActive * 20); ?>
                <div class="profile-stat"><div class="profile-stat-head"><small>Active orders</small><b><?= $buyerActive ?></b></div><div class="stat-track"><i style="width:<?= $activePercent ?>%"></i></div><span class="stat-progress-caption"><?= $activePercent ?>% active capacity</span></div>
              <?php endif; ?>
            </div>
            <?php if (!$profPremium): ?><div class="profile-progress-note">★ Pro members can choose which buyer stats appear while your progress remains visible for free.</div><?php endif; ?>
          </div>
        <?php endif; ?>
      </div>

      <aside class="stack">
        <div class="card card-pad">
          <h3 style="font-size:1rem;margin-bottom:.8rem">Reviews</h3>
          <?php if (count($reviews) > 0): ?>
            <?php foreach ($reviews as $rv): ?>
              <div style="padding:.7rem 0;border-bottom:1px dashed var(--line)">
                <div class="flex gap-2" style="gap:.6rem">
                  <?= avatar_of($rv, 28) ?>
                  <div>
                    <b style="font-size:var(--fs-sm)"><?= e(member_name($rv)) ?></b>
                    <div class="muted" style="font-size:var(--fs-xs)"><?= time_ago((string) $rv['created_at']) ?></div>
                  </div>
                  <div style="margin-left:auto"><?= star_row((float) $rv['rating']) ?></div>
                </div>
                <?php if (trim((string) $rv['comment']) !== ''): ?>
                  <p class="muted" style="font-size:var(--fs-sm);margin:0 0 0 34px;margin-top:.35rem"><?= e($rv['comment']) ?></p>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p class="muted" style="font-size:var(--fs-sm);margin:0">No reviews yet — first orders earn the trust.</p>
          <?php endif; ?>
        </div>

        <div class="card card-pad">
          <h3 style="font-size:.95rem;margin-bottom:.6rem"><?= ui_icon('shield') ?> Safety note</h3>
          <p class="muted" style="font-size:var(--fs-sm);margin:0">This profile <?= $prof['account_status'] === 'verified' ? 'has been' : 'is still being' ?> manually verified. Always keep chat and payments inside Nerasky.</p>
        </div>
      </aside>
    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
<script>
document.querySelectorAll('[data-share-profile]').forEach(function (button) {
  button.addEventListener('click', function () {
    var url = button.getAttribute('data-share-profile');
    var status = button.parentElement.querySelector('.profile-share-status');
    if (navigator.share) {
      navigator.share({title: document.title, url: url}).catch(function () {});
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(new URL(url, window.location.href).href).then(function () {
        if (status) { status.textContent = 'Link copied'; setTimeout(function () { status.textContent = ''; }, 2200); }
      });
    } else {
      window.prompt('Copy this profile link:', new URL(url, window.location.href).href);
    }
  });
});
</script>