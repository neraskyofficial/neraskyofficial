<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$me = require_user();
$uid = (int) $me['id'];

$premium = is_premium($me);
$until = $premium && !empty($me['premium_until']) ? strtotime((string) $me['premium_until']) : null;
$savedTotal = 0;
if ($premium && !empty($me['premium_until'])) {
    $savedTotal = (float) scalar(
        "SELECT COALESCE(SUM(platform_fee), 0) FROM orders WHERE seller_id = ? AND status <> 'cancelled'",
        [$uid]
    );
}

$history = rows("SELECT * FROM subscriptions WHERE user_id = ? ORDER BY id DESC LIMIT 8", [$uid]);

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'subscribe') {
        $wallet = (float) $me['wallet'];
        if ($wallet < PREMIUM_PRICE) {
            $errors[] = 'Not enough wallet balance — you need at least ' . money((float) PREMIUM_PRICE) . ' to go Pro. You have ' . money($wallet) . '.';
        } else {
            $now = time();
            $startsAt = ($premium && $until && $until > $now) ? date('Y-m-d H:i:s', $until) : date('Y-m-d H:i:s', $now);
            $endsAt   = ($premium && $until && $until > $now) ? date('Y-m-d H:i:s', $until + PREMIUM_DAYS * 86400) : date('Y-m-d H:i:s', $now + PREMIUM_DAYS * 86400);
            if (!wallet_debit($uid, (float) PREMIUM_PRICE, 'Nerasky Pro subscription', null, 'subscription')) {
                $errors[] = 'Your wallet balance changed before checkout could finish. Please try again.';
            } else {
                q('UPDATE users SET premium_until = ? WHERE id = ?', [$endsAt, $uid]);
                insert(
                    'INSERT INTO subscriptions (user_id, plan, amount, source, starts_at, ends_at, status)
                     VALUES (?,?,?,?,?,?,?)',
                    [$uid, 'pro', PREMIUM_PRICE, 'wallet', $startsAt, $endsAt, 'active']
                );
                flash('ok', 'Welcome to Nerasky Pro! ★ Your listings are boosted and you now get the 97% rate on your first ' . PREMIUM_DAILY_DISCOUNTED_ORDERS . ' orders each day.');
                redirect('premium.php');
            }
        }
    }

    if ($action === 'cancel') {
        q("UPDATE subscriptions SET status = 'cancelled' WHERE user_id = ? AND status = 'active'", [$uid]);
        q('UPDATE users SET premium_until = NULL WHERE id = ?', [$uid]);
        flash('info', 'Your Pro membership has been cancelled. You can re-subscribe anytime.');
        redirect('premium.php');
    }
}
$me = get_user(); // refresh after actions
$premium = is_premium($me);

$pageTitle  = 'Nerasky Pro';
$currentNav = 'premium';
require __DIR__ . '/includes/header.php';
?>
<section class="page-head reveal" style="background:var(--dark);padding:3.2rem 0 2.6rem">
  <div class="container flex-between" style="align-items:flex-end">
    <div>
      <span class="eyebrow" style="color:#a5b4fc">Membership</span>
      <h1 style="color:#fff;font-size:2.2rem;margin-bottom:.2rem">Nerasky <span style="background:linear-gradient(135deg,#f59e0b,#f97316);-webkit-background-clip:text;background-clip:text;color:transparent">Pro</span></h1>
      <p style="color:#8b93b8;margin:0">More exposure, a smaller cut, for less than a cup of coffee.</p>
    </div>
    <?php if ($premium): ?><span class="pill pill-ok" style="font-size:.85rem"><span class="dot"></span>★ Pro active</span><?php endif; ?>
  </div>
</section>

<section class="section-tight">
  <div class="container">
    <?php foreach ($errors as $err): ?>
      <div class="banner banner-bad mb-2"><span class="b-ic">✕</span><span><?= e($err) ?></span></div>
    <?php endforeach; ?>

    <div class="order-summary">
      <div class="stack">
        <div class="card card-pad reveal">
          <div class="flex-between mb-2">
            <h2 style="font-size:1.25rem;margin:0">Your membership</h2>
            <?php if ($premium): ?><?= premium_badge('lg') ?><?php else: ?><span class="pill pill-muted">Not a Pro member</span><?php endif; ?>
          </div>

          <?php if ($premium): ?>
            <div class="flex gap-2" style="gap:.8rem;flex-wrap:wrap">
              <div class="stat-card"><div class="st-ic"><?= ui_icon('clock') ?></div><div><b><?= $until ? date('M j, Y', $until) : '—' ?></b><small>Renews / expires</small></div></div>
              <div class="stat-card"><div class="st-ic"><?= ui_icon('trending') ?></div><div><b><?= (int) PREMIUM_FEE ?>%</b><small>First <?= (int) PREMIUM_DAILY_DISCOUNTED_ORDERS ?> orders/day</small></div></div>
              <div class="stat-card"><div class="st-ic"><?= ui_icon('cash') ?></div><div><b><?= money($savedTotal) ?></b><small>Fees on your orders</small></div></div>
            </div>
            <div class="banner banner-ok mt-2"><span class="b-ic">★</span><span>You keep <b>97%</b> on your first <b><?= (int) PREMIUM_DAILY_DISCOUNTED_ORDERS ?> orders each day</b>, your listings are <b>boosted to the top</b> of browse, and you can send up to <b><?= PREMIUM_DAILY_MESSAGES ?> messages per day</b>.</span></div>
          <?php else: ?>
            <p class="muted" style="font-size:var(--fs-sm)">You're on the free plan: a 5% platform fee, standard listing placement, and <?= FREE_DAILY_MESSAGES ?> messages per day. Go Pro for a daily <?= (int) PREMIUM_DAILY_DISCOUNTED_ORDERS ?>-order 3% allowance, boosted placement, and up to <?= PREMIUM_DAILY_MESSAGES ?> messages per day.</p>
          <?php endif; ?>
        </div>

        <div class="panel">
          <div class="panel-head"><h3>Subscription history</h3></div>
          <?php if (count($history) > 0): ?>
            <?php foreach ($history as $sub): ?>
              <div class="order-row">
                <span class="st-ic" style="width:40px;height:40px;border-radius:12px;background:rgb(245 158 11/.12);display:flex;align-items:center;justify-content:center">★</span>
                <div class="or-main">
                  <b>Nerasky Pro · <?= money((float) $sub['amount']) ?></b>
                  <small>Paid via <?= ($sub['source'] ?? 'wallet') === 'paymongo' ? 'PayMongo QR Ph' : 'wallet' ?> · started <?= date('M j, Y', strtotime((string) $sub['starts_at'])) ?> → ends <?= date('M j, Y', strtotime((string) $sub['ends_at'])) ?></small>
                </div>
                <?= sb((string) $sub['status']) ?>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="empty-state"><div class="es-ic"><?= ui_icon('sparkle') ?></div><b>No subscriptions yet</b><p class="muted">Your Pro journey starts with one click below.</p></div>
          <?php endif; ?>
        </div>
      </div>

      <aside class="stack">
<div class="card card-pad pro-hero reveal cascade" style="border-color:rgb(245 158 11/.4)">
          <div class="flex-between mb-2">
            <h3 style="font-size:1.1rem;margin:0">★ Pro membership</h3>
            <?= premium_badge('lg') ?>
          </div>
          <div style="font-size:2rem;font-weight:800;color:var(--ink-900)"><?= price((float) PREMIUM_PRICE) ?><span class="faint" style="font-size:.9rem;font-weight:600"> / <?= PREMIUM_DAYS ?> days</span></div>
          <p class="muted" style="font-size:var(--fs-sm);margin:.4rem 0 1rem">One-time wallet charge, renewable. Cancel anytime.</p>

          <div class="stack gap-2" style="gap:.6rem">
            <div class="flex gap-2" style="gap:.6rem"><span style="color:var(--green-600)">✓</span><span style="font-size:var(--fs-sm)"><b>97%</b> on your first <?= (int) PREMIUM_DAILY_DISCOUNTED_ORDERS ?> orders each day — then the standard 5% fee applies</span></div>
            <div class="flex gap-2" style="gap:.6rem"><span style="color:var(--green-600)">✓</span><span style="font-size:var(--fs-sm)">Boosted placement in browse &amp; landing</span></div>
            <div class="flex gap-2" style="gap:.6rem"><span style="color:var(--green-600)">✓</span><span style="font-size:var(--fs-sm)">★ Pro badge on your profile and listings</span></div>
            <div class="flex gap-2" style="gap:.6rem"><span style="color:var(--green-600)">✓</span><span style="font-size:var(--fs-sm)">Premium profile frames and Spotlight or Centered layouts</span></div>
            <div class="flex gap-2" style="gap:.6rem"><span style="color:var(--green-600)">✓</span><span style="font-size:var(--fs-sm)">Priority seller insights</span></div>
            <div class="flex gap-2" style="gap:.6rem"><span style="color:var(--green-600)">✓</span><span style="font-size:var(--fs-sm)"><b><?= PREMIUM_DAILY_MESSAGES ?> messages/day</b> and <?= PREMIUM_MESSAGE_MAX_CHARS ?> characters per message</span></div>
          </div>

          <?php if ($premium): ?>
            <form method="post" action="<?= e(base_url('premium.php')) ?>" class="mt-3">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="subscribe">
              <button class="btn btn-primary btn-block btn-lg" type="submit">Extend by <?= PREMIUM_DAYS ?> days (+<?= price((float) PREMIUM_PRICE) ?>)</button>
            </form>
            <?php
            $checkoutPurpose = 'pro';
            $checkoutButton = 'Extend Pro with QR Ph';
            $checkoutAmount = (float) PREMIUM_PRICE;
            require __DIR__ . '/includes/paymongo_checkout_ui.php';
            ?>
            <form method="post" action="<?= e(base_url('premium.php')) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="cancel">
              <button class="btn btn-ghost btn-block" type="submit" style="margin-top:.5rem" data-confirm="Cancel your Pro membership? You'll go back to the 5% fee.">✕ Cancel membership</button>
            </form>
          <?php else: ?>
            <div class="flex-between mt-3" style="gap:.6rem;align-items:flex-start">
              <div style="font-size:var(--fs-xs);color:var(--faint)">Wallet balance: <b style="color:var(--ink-900)"><?= money((float) $me['wallet']) ?></b></div>
              <a class="btn btn-ghost btn-sm" href="<?= e(base_url('wallet.php')) ?>">Fund wallet →</a>
            </div>
            <form method="post" action="<?= e(base_url('premium.php')) ?>" class="mt-2">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="subscribe">
              <button class="btn btn-primary btn-block btn-lg" type="submit" <?= (float) $me['wallet'] < PREMIUM_PRICE ? 'disabled' : '' ?>>
                Go Pro — <?= price((float) PREMIUM_PRICE) ?> <?= ui_icon('sparkle') ?>
              </button>
            </form>
            <?php
            $checkoutPurpose = 'pro';
            $checkoutButton = 'Go Pro with QR Ph';
            $checkoutAmount = (float) PREMIUM_PRICE;
            require __DIR__ . '/includes/paymongo_checkout_ui.php';
            ?>
            <?php if ((float) $me['wallet'] < PREMIUM_PRICE): ?><p class="hint center mt-1" style="font-size:.78rem">Or add funds from your <a href="<?= e(base_url('wallet.php')) ?>">wallet</a> or earn them from completed orders.</p><?php endif; ?>
          <?php endif; ?>
        </div>

        <div class="card card-pad" style="background:rgb(99 102 241/.04)">
          <h3 style="font-size:.95rem"><?= ui_icon('zap') ?> Pro tips</h3>
          <p class="muted" style="font-size:var(--fs-sm);margin:0">The 2% rate difference on a ₱500 order is ₱10 — on ten orders a month, your subscription pays for itself. Boosted listings also mean more views and more orders.</p>
        </div>
      </aside>
    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>