<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

if (get_user()) {
    redirect(safe_next((string) ($_GET['next'] ?? '')));
}

$errors = [];
$email  = '';
$next   = safe_next((string) ($_GET['next'] ?? $_POST['next'] ?? ''));
$unverifiedEmail = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $ip   = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    // Brute-force throttle: cap failed attempts per IP and per e-mail.
    $loginKey = 'login:' . $ip;
    if (!throttle_allows($loginKey, 20, 900)) { // 20 tries / 15 min per IP
        $errors[] = 'Too many sign-in attempts from this address. Please wait ' . ceil(throttle_retry_after($loginKey) / 60) . ' minute(s) and try again.';
    }

    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $pass  = (string) ($_POST['password'] ?? '');

    $emailKey = $email !== '' ? 'user:' . hash('sha256', $email) : '';
    if ($emailKey !== '' && $errors === [] && !throttle_allows($emailKey, 5, 900)) {
        $errors[] = 'Too many failed attempts. Please wait and try again in a few minutes.';
    }

    $u = row('SELECT * FROM users WHERE email = ?', [$email]);
    if ($u && password_verify($pass, $u['password_hash'])) {
        if ($u['account_status'] === 'rejected') {
            $errors[] = 'This account was not approved. Contact an admin if you believe this is a mistake.';
        } else {
            if ((int) $u['email_verified'] !== 1) {
                $supabaseAuth = supabase_password_sign_in($email, $pass);
                if ($supabaseAuth['ok'] && supabase_user_email_confirmed($supabaseAuth['user'])) {
                    q('UPDATE users SET supabase_uid = ?, email_verified = 1,
                       email_verified_at = COALESCE(email_verified_at, NOW()) WHERE id = ?',
                      [(string) ($supabaseAuth['user']['id'] ?? ''), (int) $u['id']]);
                    $u['email_verified'] = 1;
                } else {
                    $migrated = false;
                    if (!$supabaseAuth['ok']
                        && !empty($u['firebase_uid'])
                        && empty($u['supabase_uid'])
                        && in_array($supabaseAuth['code'] ?? '', ['user_not_found', 'invalid_credentials'], true)) {
                        $migration = supabase_send_signup_confirmation($email, $pass, (string) $u['full_name']);
                        if ($migration['ok']) {
                            $remoteUser = $migration['data']['user'] ?? [];
                            $remoteId = is_array($remoteUser) ? (string) ($remoteUser['id'] ?? '') : '';
                            if ($remoteId !== '') {
                                q('UPDATE users SET supabase_uid = ? WHERE id = ?', [$remoteId, (int) $u['id']]);
                            }
                            $errors[] = 'We are setting up your account. Open the confirmation e-mail we sent to finish signing in.';
                            $migrated = true;
                        }
                    }
                    if (!$migrated) {
                        $errors[] = $supabaseAuth['ok']
                            ? 'Please confirm your e-mail address using the link we sent, then log in again.'
                            : 'Please confirm your e-mail address using the link we sent, or request a new one below.';
                    }
                    $unverifiedEmail = $email;
                }
            }
        }

        if ((int) $u['email_verified'] === 1 && $errors === []) {
            // Reset any prior throttle counters for this success.
            if ($emailKey !== '') {
                q('DELETE FROM security_throttle WHERE key_hash = ?', [hash('sha256', 'user:' . hash('sha256', $email))]);
            }
            session_regenerate_id(true);
            $_SESSION['uid'] = (int) $u['id'];
            stamp_login();
            flash('ok', 'Welcome back, ' . $u['full_name'] . '!');
            redirect($next);
        }
    } else {
        $errors[] = 'That email or password doesn\'t match any verified student.';
    }
}

$pageTitle  = 'Log in';
$currentNav = 'login';
require __DIR__ . '/includes/header.php';
?>

<div class="auth-shell">
  <aside class="auth-left">
    <div class="flex" style="gap:.7rem">
      <?= logo_svg(44) ?>
      <div>
        <b style="font-size:1.25rem;color:#fff">Nerasky</b>
        <div style="font-size:.78rem;color:#8b93b8">A marketplace for student talent</div>
      </div>
    </div>
    <div>
      <h2>Your next opportunity starts <span style="color:#a5b4fc">right here</span>.</h2>
      <div class="al-feats">
        <div class="al-feat"><span class="fd">5%</span><div><b>Flat fee, always</b><small>Sellers keep 95% of every completed order.</small></div></div>
        <div class="al-feat"><span class="fd">✓</span><div><b>Accounts reviewed by moderators</b><small>Eligibility checks and parental consent for minors.</small></div></div>
        <div class="al-feat"><span class="fd"><?= ui_icon('lock') ?></span><div><b>Privacy-first by design</b><small>Clear workflows, purposeful data use, and no tracking pixels.</small></div></div>
      </div>
    </div>
    <p class="al-quote" style="margin:0">A student-first marketplace for learning, earning, and collaborating.</p>
  </aside>

  <section class="auth-right">
    <div class="auth-card reveal">
      <span class="eyebrow">Welcome back</span>
      <h2 style="font-size:1.7rem">Log in to Nerasky</h2>
      <p class="muted">New here? <a href="<?= e(base_url('register.php?next=' . urlencode($next))) ?>" style="font-weight:700">Create an account</a> — it takes under a minute.</p>

      <?php foreach ($errors as $err): ?>
        <div class="banner banner-bad mb-2"><span class="b-ic">✕</span><span><?= e($err) ?></span></div>
      <?php endforeach; ?>

      <?php if (!empty($_GET['verify'])): ?>
        <div class="banner banner-ok mb-2"><span class="b-ic">✓</span>
          <span>Account created. Open the confirmation link we sent to finish signing in.</span></div>
      <?php endif; ?>

      <?php if (!empty($_GET['resend'])): ?>
        <div class="banner banner-ok mb-2"><span class="b-ic">✓</span>
          <span>If the address belongs to an unconfirmed account, we will send a new confirmation e-mail.</span></div>
      <?php endif; ?>

      <?php if ($unverifiedEmail !== ''): ?>
        <form method="post" action="<?= e(base_url('verify_email.php')) ?>" class="mt-2">
          <?= csrf_field() ?>
          <input type="hidden" name="resend_email" value="<?= e($unverifiedEmail) ?>">
          <button class="btn btn-ghost btn-block" type="submit">Resend confirmation e-mail →</button>
        </form>
      <?php endif; ?>

      <form method="post" action="<?= e(base_url('login.php')) ?>" class="mt-3">
        <?= csrf_field() ?>
        <input type="hidden" name="next" value="<?= e($next) ?>">
        <div class="field">
          <label for="email">School email</label>
          <input class="input" type="email" id="email" name="email" required value="<?= e($email) ?>" placeholder="you@student.ph" autocomplete="email">
        </div>
        <div class="field">
          <label for="password">Password</label>
          <input class="input" type="password" id="password" name="password" required placeholder="••••••••" autocomplete="current-password">
        </div>
        <button class="btn btn-primary btn-lg btn-block mt-2" type="submit">Log in →</button>
      </form>

      <div class="auth-switch">
        Need help signing in? <a href="<?= e(base_url('support.php')) ?>">Contact Nerasky support</a>.
      </div>
    </div>
  </section>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>