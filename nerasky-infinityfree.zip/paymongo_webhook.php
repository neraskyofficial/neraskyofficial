<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/paymongo.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo '{"error":"Method not allowed"}';
    exit;
}

$rawBody = file_get_contents('php://input');
$signature = (string) ($_SERVER['HTTP_X_PAYMONGO_SIGNATURE'] ?? '');
if (!is_string($rawBody) || strlen($rawBody) > 262144
    || !paymongo_verify_webhook_signature($rawBody, $signature)) {
    http_response_code(400);
    echo '{"error":"Invalid webhook signature or payload"}';
    exit;
}

try {
    $event = json_decode($rawBody, true, 32, JSON_THROW_ON_ERROR);
    if (!is_array($event)) {
        throw new InvalidArgumentException('Invalid webhook event.');
    }
    paymongo_handle_webhook_event($event);
    http_response_code(200);
    echo '{"ok":true}';
} catch (Throwable $e) {
    error_log('PayMongo webhook processing failed: ' . $e->getMessage());
    http_response_code(500);
    echo '{"error":"Webhook processing failed"}';
}
