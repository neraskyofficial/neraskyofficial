<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$me = require_user();
$uid = (int) $me['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if ((string) ($_POST['action'] ?? '') === 'mark_all') {
        mark_all_notifications_read($uid);
        flash('ok', 'All notifications marked as read.');
    }
    redirect('notifications.php');
}

$notifications = rows(
    'SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 100',
    [$uid]
);
$pageTitle = 'Notifications';
$currentNav = 'notifications';
require __DIR__ . '/includes/header.php';
?>

<section class="section">
  <div class="container" style="max-width:820px">
    <div class="section-head flex-between">
      <div>
        <span class="eyebrow">Your activity</span>
        <h1>Notifications</h1>
        <p>Keep track of messages, payments, orders, and account updates.</p>
      </div>
      <?php if ($notifications !== []): ?>
        <form method="post">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="mark_all">
          <button class="btn btn-outline btn-sm" type="submit">Mark all read</button>
        </form>
      <?php endif; ?>
    </div>

    <div class="card" style="overflow:hidden">
      <div class="notif-list">
        <?php if ($notifications === []): ?>
          <div class="empty-state" style="padding:3rem 1.5rem">
            <div class="es-ic"><?= ui_icon('bell', 30) ?></div>
            <b>All caught up</b>
            <p class="muted">Notifications for messages, payments, and orders will appear here.</p>
          </div>
        <?php else: ?>
          <?php foreach ($notifications as $notification): ?>
            <a class="notif-item<?= empty($notification['is_read']) ? ' unread' : '' ?>" href="<?= e(base_url((string) $notification['link'])) ?>">
              <span class="notif-ic"><?= notif_icon((string) $notification['kind']) ?></span>
              <span class="notif-item-main">
                <span><?= e((string) $notification['text']) ?></span>
                <small><?= e(time_ago((string) $notification['created_at'])) ?></small>
              </span>
            </a>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
