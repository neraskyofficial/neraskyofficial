<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

header('Content-Type: application/json; charset=UTF-8');

$u = get_user();
if (!$u) {
    echo json_encode(['ok' => false]);
    exit;
}
verify_csrf();

/* Mark all notifications read (from the bell). */
mark_all_notifications_read((int) $u['id']);
echo json_encode(['ok' => true]);
exit;