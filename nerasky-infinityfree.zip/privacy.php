<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
$pageTitle = 'Privacy policy';
$currentNav = '';
require __DIR__ . '/includes/header.php';
?>
<section class="privacy-hero">
  <div class="container privacy-hero-grid">
    <div class="privacy-hero-copy reveal">
      <span class="eyebrow">Trust &amp; safety</span>
      <h1>Your privacy is part of the product.</h1>
      <p class="privacy-lead">Nerasky is built to help students move forward with confidence. Here is the clear, human explanation of what we collect, why we need it, and the choices you have.</p>
      <div class="privacy-updated"><span class="privacy-status-dot"></span><span>Clear handling and purpose</span><span class="privacy-divider">·</span><span>Last reviewed September 2026</span></div>
    </div>
    <div class="privacy-hero-card reveal reveal-delay-2">
      <div class="privacy-lock"><?= ui_icon('shield', 28) ?></div>
      <strong>Your information stays purposeful.</strong>
      <p>We only use information needed to run the marketplace, protect users, and resolve orders fairly.</p>
      <div class="privacy-card-line"><span>Data minimization</span><b>01</b></div>
      <div class="privacy-card-line"><span>Human review</span><b>02</b></div>
      <div class="privacy-card-line"><span>No tracking pixels</span><b>03</b></div>
    </div>
  </div>
</section>

<section class="section privacy-content">
  <div class="container privacy-layout">
    <aside class="privacy-sidebar reveal">
      <span class="privacy-sidebar-label">On this page</span>
      <a href="#information">Information we store</a>
      <a href="#use">How we use it</a>
      <a href="#providers">Hosting &amp; service providers</a>
      <a href="#documents">Documents &amp; retention</a>
      <a href="#cookies">Cookies &amp; sessions</a>
      <a href="#choices">Your choices</a>
      <div class="privacy-sidebar-note"><span><?= ui_icon('lock', 16) ?></span><p>Simple promise: your data should work for you, not against you.</p></div>
    </aside>
    <article class="legal-page privacy-article" data-stagger="90">
      <div class="privacy-section reveal" id="information">
        <span class="privacy-number">01</span>
        <div><h2>Information we store</h2><p>Depending on how you use Nerasky, the site may store your name, email address, date of birth, password hash, school or government ID image, parental-consent document, profile and service details, messages, order and payment references, payment-proof images, and wallet activity. Signup fields explain which information is required and why before you submit it.</p></div>
      </div>
      <div class="privacy-section reveal" id="use">
        <span class="privacy-number">02</span>
        <div><h2>How we use it</h2><p>Information is used to create and secure accounts, confirm email addresses, review age and identity eligibility, process orders and payments, provide support, prevent abuse, and keep payment records. Nerasky does not ask for your school, email, GCash, or PayMongo password or one-time code. Do not submit those credentials in forms, support messages, or payment notes.</p></div>
      </div>
      <div class="privacy-section reveal" id="providers">
        <span class="privacy-number">03</span>
        <div><h2>Hosting &amp; service providers</h2><p>Nerasky is an independent student marketplace and is not an official website of a school, government agency, GCash, or PayMongo. The site operator selects the hosting provider that stores marketplace data and uploaded files. Supabase provides sign-in and email-confirmation services. PayMongo processes checkout payments when that option is enabled. If you choose manual GCash payment, you use GCash separately and submit a transaction reference or proof to Nerasky for moderator review. These providers process information under their own terms and privacy policies; they are not Nerasky-operated services. Only use payment services through the options shown in the authenticated Nerasky checkout, and never share payment passwords or one-time codes.</p></div>
      </div>
      <div class="privacy-section reveal" id="documents">
        <span class="privacy-number">04</span>
        <div><h2>Documents &amp; retention</h2><p>Identity documents, parental-consent forms, payment proofs, resumes, and deliverables are stored by the hosting provider selected by the site operator. Access is intended for the account holder and authorized moderators who need the files for verification, payment review, support, or safety. Do not upload documents until you are comfortable with this use. You may request deletion or correction through your authenticated support account; requests may be subject to records the operator must retain. The operator should promptly remove files that are no longer needed and verify that hosting permissions prevent public access.</p></div>
      </div>
      <div class="privacy-section reveal" id="choices">
        <span class="privacy-number">05</span>
        <div><h2>Your choices</h2><p>You may request corrections, withdraw an application, close your account, or ask an administrator to review stored data through the authenticated Support page. Review the guide before registering if you need help understanding the marketplace.</p><a class="btn btn-outline privacy-contact" href="<?= e(base_url('guide.php#faq')) ?>">Read the guide and FAQs <?= ui_icon('arrow-right', 15) ?></a></div>
      </div>
      <div class="privacy-section reveal" id="cookies">
        <span class="privacy-number">06</span>
        <div><h2>Cookies &amp; sessions</h2><p>Nerasky uses one strictly necessary session cookie to keep accounts signed in, protect forms, and maintain secure user sessions. It does not contain advertising identifiers and is not used to track users across other websites.</p><p>Nerasky does not use analytics, advertising, or cross-site tracking cookies. The session cookie is protected with HttpOnly and SameSite safeguards, and receives the Secure flag when the site is running over HTTPS.</p></div>
      </div>
    </article>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
