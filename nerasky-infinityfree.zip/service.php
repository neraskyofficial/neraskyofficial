<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$id = (int) ($_GET['id'] ?? 0);
$sv = null;
if ($id > 0) {
    try {
        $sv = row('SELECT s.*, u.full_name, u.bio, u.is_minor, u.profile_frame, u.profile_accent
                   FROM services s JOIN users u ON u.id = s.seller_id
                   WHERE s.id = ?', [$id]);
    } catch (Throwable $e) {
        /* DB not installed yet */
    }
}

if (!$sv) {
    $pageTitle = 'Service not found';
    require __DIR__ . '/includes/header.php';
    echo '<section class="section"><div class="container"><div class="card empty-state">'
        . '<div class="es-ic">' . ui_icon('search') . '</div><b>Service not found</b>'
        . '<p class="muted">This listing doesn\'t exist or is no longer available.</p>'
        . '<a class="btn btn-primary" href="' . e(base_url('browse.php')) . '">Back to browse</a>'
        . '</div></div></section>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

remember_viewed_service($id);
$me = get_user();
$seller = (int) $sv['seller_id'];
$sellerUser = row('SELECT id, full_name, premium_until FROM users WHERE id = ?', [$seller]);
$premiumSeller = is_premium($sellerUser);
$feeRate = effective_fee_rate($sellerUser);
$premiumOrdersLeft = $premiumSeller ? max(0, PREMIUM_DAILY_DISCOUNTED_ORDERS - premium_orders_today($sellerUser)) : 0;
$fee = fee_for((float) $sv['price'], $sellerUser);
$payout = payout_for((float) $sv['price'], $sellerUser);
$serviceImages = rows('SELECT id, image_path FROM service_images WHERE service_id = ? ORDER BY sort_order, id', [$id]);
$rating = seller_rating($seller);
$reviews = rows('SELECT r.*, u.full_name, u.profile_frame, u.profile_accent FROM reviews r JOIN users u ON u.id = r.reviewer_id WHERE r.reviewee_id = ? ORDER BY r.id DESC LIMIT 5', [$seller]);
$otherSvcs = rows('SELECT id, title, price, delivery_days FROM services WHERE seller_id = ? AND id <> ? AND status = "active" LIMIT 4', [$seller, $id]);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    verify_csrf();
    $u = require_user();
    if ($u['account_status'] !== 'verified') {
        flash('warn', 'Your account is still under review. You can place orders once an admin verifies you.');
        redirect('dashboard.php');
    }
    if ((int) $u['id'] === $seller) {
        flash('warn', 'You can\'t order your own service — pick another seller!');
        redirect('service.php?id=' . $id);
    }
    $notes = trim((string) ($_POST['notes'] ?? ''));
    try {
        $oid = insert(
            'INSERT INTO orders (service_id, buyer_id, seller_id, price, platform_fee, seller_payout, notes, status)
             VALUES (?,?,?,?,?,?,?,?)',
            [$id, $u['id'], $seller, (float) $sv['price'], $fee, $payout, $notes, 'awaiting_payment']
        );
    } catch (PDOException $e) {
        error_log('Order creation failed for service #' . $id . ': ' . $e->getMessage());
        flash('bad', 'We could not create this order. Please refresh the service page and try again. If it keeps happening, contact support.');
        redirect('service.php?id=' . $id);
    }

    try {
        notify($seller, 'order', $u['full_name'] . ' placed order #' . $oid . ' for "' . mb_strimwidth((string) $sv['title'], 0, 40, '…') . '".', 'order.php?order=' . $oid);
    } catch (Throwable $e) {
        error_log('Seller notification failed for order #' . $oid . ': ' . $e->getMessage());
        flash('warn', 'Your order was created, but the seller notification could not be sent. You can still continue to payment and contact the seller from the order page.');
        redirect('order.php?order=' . $oid);
    }
    flash('ok', 'Order created! Pay from your Nerasky wallet or choose another available payment option to start the protected order.');
    redirect('order.php?order=' . $oid);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_save'])) {
    verify_csrf();
    $u = require_user();
    $saved = toggle_saved_service((int) $u['id'], $id);
    flash('ok', $saved ? 'Service saved.' : 'Service removed from saved services.');
    $return = match ($_POST['return'] ?? '') {
        'saved' => 'saved.php',
        'browse' => 'browse.php',
        default => 'service.php?id=' . $id,
    };
    redirect($return);
}

$pageTitle = $sv['title'];
$saved = $me ? is_service_saved((int) $me['id'], $id) : false;
require __DIR__ . '/includes/header.php';
?>

<section class="section-tight">
  <div class="container">
    <nav style="font-size:var(--fs-xs);color:var(--muted);margin-bottom:1.2rem">
      <a href="<?= e(base_url('browse.php')) ?>">Browse</a> /
      <a href="<?= e(base_url('browse.php?category=' . urlencode($sv['category']))) ?>"><?= e($sv['category']) ?></a> /
      <span><?= e(mb_strimwidth($sv['title'], 0, 46, '…')) ?></span>
    </nav>

    <div class="order-summary">
      <div class="stack">
        <article class="card card-pad service-detail-card reveal">
          <div class="flex-between mb-1">
            <span class="sv-cat" style="display:inline-flex;align-items:center;gap:.5rem;font-size:var(--fs-xs);font-weight:700;color:var(--brand-600);background:rgb(99 102 241/.08);padding:.3rem .7rem;border-radius:var(--r-pill)">
              <?= cat_icon($sv['category']) ?> <?= e($sv['category']) ?>
            </span>
            <span class="muted" style="font-size:var(--fs-sm)">⏱ Delivered in <?= (int) $sv['delivery_days'] ?> day<?= (int) $sv['delivery_days'] > 1 ? 's' : '' ?></span>
          </div>
          <h1 class="service-detail-title"><?= e($sv['title']) ?></h1>
          <form method="post" action="<?= e(base_url('service.php?id=' . $id)) ?>" style="margin:.7rem 0">
            <?= csrf_field() ?>
            <button class="btn btn-outline btn-sm" type="submit" name="toggle_save" value="1"><?= $saved ? '★ Saved' : '☆ Save service' ?></button>
          </form>
          <p style="color:var(--ink-700);white-space:pre-wrap"><?= e($sv['description']) ?></p>

          <div class="mt-3 flex-between" style="border-top:1px solid var(--line);padding-top:1.2rem">
            <div class="flex">
              <?= avatar_of($sv, 46) ?>
              <div>
                <b><?= e(member_name($sv)) ?> <?php if ($premiumSeller): ?><?= premium_badge() ?><?php endif; ?></b>
                <div class="muted" style="font-size:var(--fs-xs)">
                  <?= $sv['is_minor'] ? 'Verified · minor (approved consent)' : 'Manually verified seller' ?>
                  <?php if ($me && $premiumSeller): ?> · gets 97% on the first <?= (int) PREMIUM_DAILY_DISCOUNTED_ORDERS ?> orders each day<?php endif; ?>
                  <?php if ($rating !== null): ?> · <?= star_row($rating) ?> <?= number_format($rating, 1) ?> (<?= count($reviews) ?>)<?php endif; ?>
                </div>
              </div>
            </div>
            <div class="flex gap-2">
              <a class="btn btn-outline btn-sm" href="<?= e(base_url('profile.php?id=' . $seller)) ?>">View profile</a>
              <?php if ($me && (int) $me['id'] === $seller): ?>
                <a class="btn btn-primary btn-sm" href="<?= e(base_url('service-edit.php?id=' . $id)) ?>"><?= ui_icon('pen', 14) ?> Edit service</a>
              <?php endif; ?>
              <?php if (get_user() && !hide_names() && (int) get_user()['id'] !== $seller): ?>
                <a class="btn btn-primary btn-sm" href="<?= e(base_url('messages.php?to=' . $seller)) ?>"><?= ui_icon('chat') ?> Message</a>
              <?php endif; ?>
            </div>
          </div>
        </article>

        <?php if ($serviceImages): ?>
          <?php $firstServiceImage = $serviceImages[0]; ?>
          <section class="card card-pad service-gallery reveal" data-service-gallery aria-label="Service work samples">
            <h2>Work showcase</h2>
            <a class="service-gallery-main" href="<?= e(asset_url((string) $firstServiceImage['image_path'])) ?>" target="_blank" rel="noopener">
              <img data-gallery-main src="<?= e(asset_url((string) $firstServiceImage['image_path'])) ?>" alt="<?= e((string) $sv['title']) ?> work sample 1">
            </a>
            <?php if (count($serviceImages) > 1): ?>
              <div class="service-gallery-thumbs" aria-label="Choose a work sample">
                <?php foreach ($serviceImages as $index => $serviceImage): ?>
                  <?php $imageUrl = asset_url((string) $serviceImage['image_path']); ?>
                  <button class="service-gallery-thumb<?= $index === 0 ? ' active' : '' ?>" type="button" data-gallery-thumb data-image-url="<?= e($imageUrl) ?>" data-image-alt="<?= e((string) $sv['title']) ?> work sample <?= $index + 1 ?>" aria-label="Show work sample <?= $index + 1 ?>" aria-pressed="<?= $index === 0 ? 'true' : 'false' ?>">
                    <img src="<?= e($imageUrl) ?>" alt="" loading="lazy">
                  </button>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </section>
        <?php endif; ?>

        <?php if (count($reviews) > 0): ?>
          <div>
            <h3 style="font-size:1.1rem">Reviews</h3>
            <div class="stack gap-2">
              <?php foreach ($reviews as $rv): ?>
                <div class="review-card">
                  <div class="rc-head">
                    <?= avatar_of($rv, 32) ?>
                    <div>
                      <b style="font-size:var(--fs-sm)"><?= e(member_name($rv)) ?></b>
                      <div class="muted" style="font-size:var(--fs-xs)"><?= time_ago((string) $rv['created_at']) ?></div>
                    </div>
                    <div style="margin-left:auto"><?= star_row((float) $rv['rating']) ?></div>
                  </div>
                  <p><?= e($rv['comment']) ?></p>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endif; ?>
      </div>
<aside class="stack service-purchase-column">
        <div class="card card-pad service-purchase-card reveal reveal-delay-1">
          <h3 class="<?= $me ? '' : 'price-guest-blur' ?>" <?= $me ? '' : 'title="Log in to view the exact price"' ?> style="font-size:1.2rem"><?= e(marketplace_price((float) $sv['price'], $me)) ?></h3>
          <p class="muted" style="font-size:var(--fs-sm)"><?= $me ? 'One-time price · no hidden charges' : 'Log in to see the exact one-time price' ?></p>
          <div class="service-trust-row"><span><?= ui_icon('shield', 14) ?> Human-reviewed payments</span><span><?= ui_icon('check', 14) ?> Secure order trail</span></div>

          <div class="fee-break mt-2">
            <?php if ($me): ?>
              <dl class="kv"><dt>You pay</dt><dd><?= money((float) $sv['price']) ?></dd></dl>
              <dl class="kv"><dt>Seller receives</dt><dd style="color:var(--green-600)"><?= money($payout) ?> <span class="faint" style="font-weight:500">(<?= 100 - (int) $feeRate ?>%)</span></dd></dl>
              <?php if ($premiumSeller): ?><dl class="kv"><dt>Pro daily rate</dt><dd class="faint"><b style="color:#b45309">★ <?= (int) $feeRate ?>% · <?= $premiumOrdersLeft ?> discounted order<?= $premiumOrdersLeft === 1 ? '' : 's' ?> left</b></dd></dl><?php endif; ?>
              <dl class="kv" style="border-bottom:0"><dt>Nerasky platform fee</dt><dd><?= money($fee) ?> <span class="faint" style="font-weight:500">(<?= (int) $feeRate ?>%)</span></dd></dl>
            <?php else: ?>
              <dl class="kv" style="border-bottom:0"><dt class="price-guest-blur">Estimated price</dt><dd>Log in to view</dd></dl>
            <?php endif; ?>
          </div>

          <form method="post" action="<?= e(base_url('service.php?id=' . $id)) ?>" class="mt-3">
            <?= csrf_field() ?>
            <div class="field">
              <label for="notes">Notes for the seller <span class="faint" style="font-weight:500">(optional)</span></label>
              <textarea class="input" id="notes" name="notes" rows="3" placeholder="Deadline, files to review, what you need most…"></textarea>
            </div>

            <?php if ($me && (int) $me['id'] === $seller): ?>
              <div class="banner banner-info"><span class="b-ic"><?= ui_icon('info') ?></span><span>This is your own service — you can't order it. <a href="<?= e(base_url('service-edit.php?id=' . $id)) ?>">Edit it instead</a>.</span></div>
            <?php elseif (!$me): ?>
              <?php $orderNext = 'service.php?id=' . $id; ?>
              <div class="banner banner-info"><span class="b-ic"><?= ui_icon('info') ?></span><span>Ready to hire? Create an account or log in — you will come straight back here to finish ordering.</span></div>
              <div class="flex gap-2 mt-2" style="flex-wrap:wrap">
                <a class="btn btn-primary btn-sm" href="<?= e(base_url('register.php?next=' . urlencode($orderNext))) ?>">Create account to order</a>
                <a class="btn btn-outline btn-sm" href="<?= e(base_url('login.php?next=' . urlencode($orderNext))) ?>">Log in</a>
              </div>
            <?php elseif ($me['account_status'] !== 'verified'): ?>
              <div class="banner banner-warn"><span class="b-ic">!</span><span>Orders unlock once a moderator verifies your account.</span></div>
            <?php else: ?>
              <button class="btn btn-primary btn-lg btn-block service-order-button" type="submit" name="place_order" value="1">Order now — <?= price((float) $sv['price']) ?></button>
              <p class="hint center mt-1" style="font-size:.78rem">After ordering, fund your Nerasky wallet if needed, then pay securely from the order page.</p>
            <?php endif; ?>
          </form>
        </div>

        <?php if (count($otherSvcs) > 0): ?>
          <div class="card card-pad">
            <h3 style="font-size:.95rem;margin-bottom:.9rem">More from this seller</h3>
            <?php foreach ($otherSvcs as $o): ?>
              <a href="<?= e(base_url('service.php?id=' . (int) $o['id'])) ?>" class="flex-between" style="padding:.55rem 0;border-bottom:1px dashed var(--line)">
                <span style="font-weight:600;font-size:var(--fs-sm);color:var(--ink-700)"><?= e(mb_strimwidth($o['title'], 0, 42, '…')) ?></span>
                <span class="<?= $me ? '' : 'price-guest-blur' ?>" <?= $me ? '' : 'title="Log in to view the exact price"' ?> style="font-weight:800;font-size:var(--fs-sm)"><?= e(marketplace_price((float) $o['price'], $me)) ?></span>
              </a>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <div class="card card-pad" style="background:rgb(99 102 241/.04)">
          <h3 style="font-size:.95rem"><?= ui_icon('shield') ?> Buyer protection on Nerasky</h3>
          <p class="muted" style="font-size:var(--fs-sm);margin:0">Wallet and PayMongo QR Ph payments must be confirmed before work starts. Chat stays in-platform and every order keeps a full paper trail.</p>
        </div>
      </aside>
    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>