<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

if (get_user()) {
    redirect(safe_next((string) ($_GET['next'] ?? '')));
}

$registrationPaused = true;
if ($registrationPaused) {
    http_response_code(503);
    $pageTitle = 'Sign-up temporarily paused';
    $currentNav = 'register';
    require __DIR__ . '/includes/header.php';
    ?>
    <section class="section">
      <div class="container" style="max-width:720px">
        <div class="card card-pad center">
          <span class="eyebrow">Privacy and safety review</span>
          <h1>New sign-ups are temporarily paused</h1>
          <p class="muted">We are reviewing the site’s safety and privacy disclosures. No new identity documents or parental-consent files are being collected. Existing account holders can still sign in. Please do not send passwords, one-time codes, identity documents, or payment details by email or message.</p>
          <div class="flex center gap-2 mt-3">
            <a class="btn btn-primary" href="<?= e(base_url('login.php')) ?>">Log in to an existing account</a>
            <a class="btn btn-outline" href="<?= e(base_url('guide.php#faq')) ?>">Read the guide</a>
          </div>
        </div>
      </div>
    </section>
    <?php
    require __DIR__ . '/includes/footer.php';
    exit;
}

$errors = [];
$next = safe_next((string) ($_GET['next'] ?? $_POST['next'] ?? ''));
$old = ['full_name' => '', 'email' => '', 'dob' => '', 'id_type' => 'school'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    // Bot defense: reject registrations where the hidden honeypot was filled.
    if (honeypot_tripped()) {
        flash('info', 'Your information looks automated. Please contact support if this is an error.');
        redirect('index.php');
    }

    // Keep the signup cap in place for real clients, but let localhost testing
    // proceed without Nerasky's IP limit. Supabase still enforces its own limits.
    $remoteAddress = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    $isLocalRequest = in_array($remoteAddress, ['127.0.0.1', '::1'], true);
    $regKey = 'register:' . $remoteAddress;
    if (!$isLocalRequest && !throttle_allows($regKey, 6, 3600)) { // 6 signups / hour per IP
        $errors[] = 'Too many accounts created from this address. Please try again later.';
    }

    $old['full_name'] = trim((string) ($_POST['full_name'] ?? ''));
    $old['email']     = strtolower(trim((string) ($_POST['email'] ?? '')));
    $old['dob']       = trim((string) ($_POST['dob'] ?? ''));
    $old['id_type']   = ($_POST['id_type'] ?? 'school') === 'government' ? 'government' : 'school';
    $password         = (string) ($_POST['password'] ?? '');
    $confirm          = (string) ($_POST['password2'] ?? '');

    if ($old['full_name'] === '' || mb_strlen($old['full_name']) < 4) {
        $errors[] = 'Please enter your full name (first and last).';
    }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if (!supabase_configured()) {
        $errors[] = 'E-mail verification is temporarily unavailable. Please try again later.';
    }
    if (($_POST['signup_acknowledgement'] ?? '') !== '1') {
        $errors[] = 'Please read and acknowledge the signup requirements before creating your account.';
    }
    if (mb_strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }
    if (strlen($password) > 72) {
        $errors[] = 'Password must be 72 bytes or fewer.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }
    if (str_contains($password, $old['full_name'])) {
        $errors[] = 'Password is too similar to your name.';
    }
    if (row('SELECT id FROM users WHERE email = ?', [$old['email']])) {
        $errors[] = 'An account with that email already exists. Try logging in instead.';
    }

    $age = null;
    $dobTs = strtotime($old['dob']);
    if ($old['dob'] === '' || $dobTs === false || $dobTs > time()) {
        $errors[] = 'Please enter your real date of birth.';
    } else {
        $age = (new DateTimeImmutable('@' . $dobTs))->diff(new DateTimeImmutable('today'))->y;
        if ($age < 15) {
            $errors[] = 'Sorry — Nerasky is only open to students aged 15 and above.';
        }
    }
    $isMinor = $age !== null && $age >= 15 && $age < 18;
    if ($isMinor && $old['id_type'] === 'government') {
        $errors[] = 'Students aged 15–17 must verify with a school ID. Government IDs are accepted from 18+.';
    }

    $verifyFile = null;
    $uploaded = upload_file($_FILES['id_file'] ?? [], 'consents', ['jpg', 'jpeg', 'png', 'webp', 'pdf']);
    if (!$uploaded[0]) {
        $errors[] = ($old['id_type'] === 'government' ? 'Government ID' : 'School ID') . ': ' . $uploaded[1];
    } else {
        $verifyFile = $uploaded[1];
    }

    $consentFile = null;
    if ($isMinor) {
        $up = upload_file($_FILES['consent_file'] ?? [], 'consents', ['jpg', 'jpeg', 'png', 'webp', 'pdf']);
        if (!$up[0]) {
            $errors[] = 'Parental consent: ' . $up[1];
        } else {
            $consentFile = $up[1];
        }
    }

    if ($errors === []) {
        $authResult = supabase_send_signup_confirmation($old['email'], $password, $old['full_name']);
        if (!$authResult['ok']) {
            error_log('Email verification signup failed: ' . ($authResult['error'] ?? 'Unknown error'));
            $errors[] = 'We could not send your verification e-mail right now. Please try again later.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $consentStatus = $isMinor ? 'submitted' : 'none';
            insert(
                'INSERT INTO users (full_name, email, password_hash, account_status, verification_file, id_type, date_of_birth, is_minor, consent_file, consent_status)
                 VALUES (?,?,?,?,?,?,?,?,?,?)',
                [$old['full_name'], $old['email'], $hash, 'pending', $verifyFile, $old['id_type'], $old['dob'], $isMinor ? 1 : 0, $consentFile, $consentStatus]
            );
            notify_admins('account', 'New signup waiting: ' . $old['full_name'] . ' (age ' . $age . ($isMinor ? ' — minor, consent to review' : '') . ').', 'admin/users.php');
            flash('ok', 'Account created! We sent a confirmation link to ' . $old['email'] . '. Open it to finish signing in.');
            redirect('login.php?verify=1&next=' . urlencode($next));
        }
    }
}

$pageTitle  = 'Sign up';
$currentNav = 'register';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-shell">
  <aside class="auth-left">
    <div class="flex" style="gap:.7rem">
      <?= logo_svg(44) ?>
      <div>
        <b style="font-size:1.25rem;color:#fff">Nerasky</b>
        <div style="font-size:.78rem;color:#8b93b8">student micro-service marketplace</div>
      </div>
    </div>
    <div>
      <h2>One skill away from your first peso.</h2>
      <div class="al-feats">
        <div class="al-feat"><span class="fd">1</span><div><b>Upload your school ID</b><small>Every account is manually verified by a human.</small></div></div>
        <div class="al-feat"><span class="fd">2</span><div><b>Minors add consent</b><small>Ages 15–17? Add a signed parental consent form for review.</small></div></div>
        <div class="al-feat"><span class="fd">3</span><div><b>Start earning</b><small>Post a service, get hired, and receive your payout through the Nerasky wallet.</small></div></div>
      </div>
    </div>
    <p class="al-quote" style="margin:0">Already have an account? <a href="<?= e(base_url('login.php')) ?>" style="font-weight:700;color:#a5b4fc">Log in →</a></p>
  </aside>

  <section class="auth-right">
    <div class="auth-card reveal">
      <span class="eyebrow">Join the market</span>
      <h2 style="font-size:1.7rem">Create your account</h2>
      <p class="muted">Under a minute. Your account is pending until a moderator verifies your details.</p>

      <section class="signup-notice" role="note" aria-labelledby="signupNoticeTitle">
        <span class="signup-notice-icon" aria-hidden="true">!</span>
        <div>
          <h3 id="signupNoticeTitle">What signup asks for and why</h3>
          <p>Nerasky is an independent student marketplace, not an official school, government, GCash, or PayMongo website. Signup asks for your name, email, date of birth, a Nerasky password, and an ID image so moderators can review account eligibility and identity. Ages 15–17 also submit parental consent before selling. Do not enter your school, email, GCash, or PayMongo password or any one-time code here. Sign-in and email confirmation use Supabase; the site and submitted files are hosted by the hosting provider selected by the site operator. Read the <a href="<?= e(base_url('privacy.php')) ?>">Privacy Policy</a> before uploading documents. Users below 15 cannot register.</p>
        </div>
      </section>

      <?php foreach ($errors as $err): ?>
        <div class="banner banner-bad mb-2"><span class="b-ic">✕</span><span><?= e($err) ?></span></div>
      <?php endforeach; ?>

      <form method="post" action="<?= e(base_url('register.php')) ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <?= honeypot_field() ?>
        <input type="hidden" name="next" value="<?= e($next) ?>">
        <div class="field">
          <label for="full_name">Full name</label>
          <input class="input" id="full_name" name="full_name" required value="<?= e($old['full_name']) ?>" placeholder="e.g. Alejandra Mendoza">
        </div>
        <div class="field">
          <label for="email">School email</label>
          <input class="input" type="email" id="email" name="email" required value="<?= e($old['email']) ?>" placeholder="you@student.ph" autocomplete="email">
        </div>
        <div class="grid-2 gap-2">
          <div class="field">
            <label for="password">Password</label>
            <input class="input" type="password" id="password" name="password" required minlength="6" maxlength="72" placeholder="6+ characters" autocomplete="new-password" data-password-strength>
            <span class="password-strength" id="passwordStrength" aria-live="polite"></span>
          </div>
          <div class="field">
            <label for="password2">Repeat password</label>
            <input class="input" type="password" id="password2" name="password2" required placeholder="Same, again" autocomplete="new-password">
          </div>
        </div>
        <div class="grid-2 gap-2">
          <div class="field">
            <label for="dobInput">Date of birth</label>
            <input class="input" type="date" id="dobInput" name="dob" required max="<?= date('Y-m-d') ?>" value="<?= e($old['dob']) ?>">
            <span class="hint">You must be at least 15 to use Nerasky.</span>
          </div>
          <div class="field">
            <label for="idType">ID you will upload</label>
            <select class="input" id="idType" name="id_type">
              <option value="school">School ID</option>
              <option value="government">Government ID (18+)</option>
            </select>
            <span class="hint">18+ may use either. 15–17 use a school ID.</span>
          </div>
        </div>

        <div id="ageNoteWrap" class="mb-2 hidden"><div id="ageNote" class="banner banner-info"></div></div>

        <div class="field">
          <label for="id_file">Upload your ID for verification</label>
          <div class="dropzone">
            <div class="dz-ic"><?= ui_icon('graduation') ?></div>
            <b><span id="idLabel">Click to upload your ID</span></b>
            <small>JPG, PNG or PDF up to 6 MB. Used only for manual verification — visible to moderators only, never shared, deleted on request (RA 10173).</small>
            <input type="file" id="id_file" name="id_file" accept=".jpg,.jpeg,.png,.webp,.pdf" class="hidden" required data-file-label="#idLabel">
          </div>
        </div>

        <div class="auth-minor-note show"><?= ui_icon('users') ?> Ages 15–17 need a signed parental consent form, reviewed by an admin before selling. Everything is checked by a human.</div>

        <div id="consentWrap" class="field mt-2 hidden">
          <label for="consent_file">Signed parental consent form</label>
          <input class="input" type="file" id="consent_file" name="consent_file" accept=".jpg,.jpeg,.png,.webp,.pdf" data-file-label="#consentHint">
          <span class="hint" id="consentHint">JPG, PNG or PDF. Must include your name, parent/guardian signature and date.</span>
        </div>

        <label class="signup-acknowledgement">
          <input type="checkbox" name="signup_acknowledgement" value="1" required>
          <span>I have read and agree to the <a href="<?= e(base_url('terms.php')) ?>" target="_blank" rel="noopener">Terms</a> and <a href="<?= e(base_url('privacy.php')) ?>" target="_blank" rel="noopener">Privacy Policy</a>, and understand the age and verification requirements above.</span>
        </label>
        <button class="btn btn-primary btn-lg btn-block mt-2" type="submit">Create my account →</button>
      </form>
    </div>
  </section>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>