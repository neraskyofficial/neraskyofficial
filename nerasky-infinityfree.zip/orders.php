<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$me  = require_user();
$uid = (int) $me['id'];

$mine   = $_GET['mine'] ?? '';
$status = $_GET['status'] ?? '';

$where  = [];
$params = [];

if ($mine === 'seller') {
    $where[] = 'o.seller_id = ?';
} elseif ($mine === 'buyer') {
    $where[] = 'o.buyer_id = ?';
} else {
    $where[] = '(o.buyer_id = ? OR o.seller_id = ?)';
    $params[] = $uid;
}
$params[] = $uid;

if ($status !== '' && in_array($status, ['awaiting_payment', 'in_progress', 'delivered', 'completed', 'cancelled'], true)) {
    $where[] = 'o.status = ?';
    $params[] = $status;
}

$orders = rows(
    'SELECT o.*, s.title AS service_title, b.full_name AS buyer_name, u.full_name AS seller_name,
            (SELECT p.status FROM payments p WHERE p.order_id = o.id ORDER BY p.id DESC LIMIT 1) AS payment_status,
            (SELECT wt.id FROM wallet_transactions wt WHERE wt.order_id = o.id AND wt.type = "wallet_payment" AND wt.direction = "debit" LIMIT 1) AS wallet_payment_id
     FROM orders o
     JOIN services s ON s.id = o.service_id
     JOIN users b    ON b.id = o.buyer_id
     JOIN users u    ON u.id = o.seller_id
     WHERE ' . implode(' AND ', $where) . '
     ORDER BY o.id DESC LIMIT 100',
    $params
);

$statusTabs = [
    ''                   => 'All',
    'awaiting_payment'   => 'Awaiting payment',
    'in_progress'        => 'In progress',
    'delivered'          => 'Delivered',
    'completed'          => 'Completed',
    'cancelled'          => 'Cancelled',
];

$pageTitle  = 'Orders';
$currentNav = 'orders';
require __DIR__ . '/includes/header.php';
?>
<section class="page-head">
  <div class="container">
    <div class="flex-between">
      <div>
        <h1>Orders</h1>
        <p class="muted">Every transaction, buyer and seller side — all in one place.</p>
      </div>
      <div class="seg">
        <a href="<?= e(base_url('orders.php')) ?>" class="<?= $mine === '' ? 'on' : '' ?>">All</a>
        <a href="<?= e(base_url('orders.php?mine=buyer')) ?>" class="<?= $mine === 'buyer' ? 'on' : '' ?>">Buying</a>
        <a href="<?= e(base_url('orders.php?mine=seller')) ?>" class="<?= $mine === 'seller' ? 'on' : '' ?>">Selling</a>
      </div>
    </div>

    <div class="status-tabs mt-3">
      <?php foreach ($statusTabs as $val => $label): ?>
        <a class="chip <?= $status === $val ? 'on' : '' ?>"
           href="<?= e(base_url('orders.php?' . ($mine !== '' ? 'mine=' . $mine . '&' : '') . ($val !== '' ? 'status=' . $val : ''))) ?>">
          <?= e($label) ?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section-tight" style="padding-top:1rem">
  <div class="container">
    <?php if (count($orders) > 0): ?>
      <div class="table-wrap">
        <table class="tbl orders-table">
          <thead>
            <tr><th>Order</th><th>Service</th><th>Counterparty</th><th>Amount</th><th>Status</th><th>When</th></tr>
          </thead>
          <tbody>
            <?php foreach ($orders as $o): ?>
              <tr>
                <td data-label="Order">
                  <div class="row-title"><b><a href="<?= e(base_url('order.php?order=' . (int) $o['id'])) ?>">#<?= (int) $o['id'] ?></a></b></div>
                  <a class="btn btn-ghost btn-sm order-view-btn" href="<?= e(base_url('order.php?order=' . (int) $o['id'])) ?>">View order</a>
                </td>
                <td data-label="Service"><div class="row-title"><b><?= e(mb_strimwidth($o['service_title'], 0, 42, '…')) ?></b></div></td>
                <td data-label="Counterparty" class="muted"><?= (int) $o['buyer_id'] === $uid ? '→ ' . e($o['seller_name']) : '← ' . e($o['buyer_name']) ?></td>
                <td data-label="Amount"><b><?= money((float) $o['price']) ?></b></td>
                  <td data-label="Status">
                    <?= sb((string) $o['status']) ?>
                    <?php if ($o['wallet_payment_id']): ?>
                      <small class="order-payment-state order-payment-ok">Payment verified · Wallet</small>
                    <?php elseif ($o['payment_status'] === 'verified'): ?>
                      <small class="order-payment-state order-payment-ok">Payment verified</small>
                    <?php elseif ($o['payment_status'] === 'pending'): ?>
                      <small class="order-payment-state order-payment-pending">Payment under review</small>
                    <?php elseif ($o['payment_status'] === 'rejected'): ?>
                      <small class="order-payment-state order-payment-bad">Payment rejected</small>
                    <?php else: ?>
                      <small class="order-payment-state">Payment not submitted</small>
                    <?php endif; ?>
                  </td>
                  <td data-label="When" class="muted" style="font-size:var(--fs-xs)"><?= time_ago((string) $o['created_at']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <div class="card empty-state">
        <div class="es-ic"><?= ui_icon('grid') ?></div>
        <b>No orders here</b>
        <p class="muted">Try another filter — or start a new order from the marketplace.</p>
        <a class="btn btn-primary" href="<?= e(base_url('browse.php')) ?>">Browse services</a>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>