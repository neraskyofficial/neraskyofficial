<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
$pageTitle = 'Refunds and disputes';
$currentNav = '';
require __DIR__ . '/includes/header.php';
?>
<section class="refund-hero">
  <div class="container refund-hero-grid">
    <div class="refund-hero-copy reveal">
      <span class="eyebrow">Order protection</span>
      <h1>Fair outcomes for every order.</h1>
      <p class="refund-lead">Clear steps for cancellations, disputes, and refunds help buyers and student sellers move forward with confidence.</p>
      <div class="refund-updated"><span class="privacy-status-dot"></span><span>Human-reviewed decisions</span><span class="privacy-divider">·</span><span>Last reviewed September 2026</span></div>
    </div>
    <div class="refund-hero-card reveal reveal-delay-2">
      <div class="refund-card-icon"><?= ui_icon('shield', 28) ?></div>
      <strong>Your payment has a clear path.</strong>
      <p>Keep communication and evidence inside Nerasky so every decision can be reviewed fairly.</p>
      <div class="refund-card-status"><span><?= ui_icon('check', 14) ?></span> Payment verified</div>
      <div class="refund-card-status"><span><?= ui_icon('lock', 14) ?></span> Work reviewed before release</div>
    </div>
  </div>
</section>

<section class="section refund-content">
  <div class="container">
    <div class="refund-intro reveal">
      <div>
        <span class="privacy-sidebar-label">How protection works</span>
        <h2>A simple process, built around trust.</h2>
      </div>
      <p>Most orders are completed smoothly. When something needs attention, these steps keep the process clear and give both sides a fair opportunity to explain what happened.</p>
    </div>

    <div class="refund-steps">
      <div class="refund-step reveal">
        <span class="refund-step-number">01</span>
        <div><h3>Verify before work begins</h3><p>Sellers should wait until payment is verified before starting. Buyers can keep order details and payment proof in one place.</p></div>
      </div>
      <div class="refund-step reveal reveal-delay-1">
        <span class="refund-step-number">02</span>
        <div><h3>Talk it through</h3><p>Use the order page and messages to clarify scope, revisions, delivery, or any concern before opening a dispute.</p></div>
      </div>
      <div class="refund-step reveal reveal-delay-2">
        <span class="refund-step-number">03</span>
        <div><h3>Review and resolve</h3><p>An administrator may request evidence from both parties and decide whether to release, cancel, or refund the order.</p></div>
      </div>
    </div>

    <div class="refund-policy-layout">
      <aside class="privacy-sidebar reveal">
        <span class="privacy-sidebar-label">On this page</span>
        <a href="#cancellation">Cancellation</a>
        <a href="#disputes">Disputes</a>
        <a href="#refund-decisions">Refund decisions</a>
        <a href="#abuse">Abuse prevention</a>
        <div class="privacy-sidebar-note"><span><?= ui_icon('info', 16) ?></span><p>Keep evidence and communication inside Nerasky for the strongest review.</p></div>
      </aside>
      <article class="legal-page refund-article" data-stagger="90">
        <div class="privacy-section reveal" id="cancellation">
          <span class="privacy-number">01</span>
          <div><h2>Cancellation</h2><p>Buyers may cancel before work begins. Sellers should not start until payment is verified. Cancellations after work begins require review by an administrator.</p></div>
        </div>
        <div class="privacy-section reveal" id="disputes">
          <span class="privacy-number">02</span>
          <div><h2>Disputes</h2><p>Either party can open a dispute from the order page before completion. Include a clear explanation and keep evidence inside Nerasky. An administrator may request additional information before deciding.</p></div>
        </div>
        <div class="privacy-section reveal" id="refund-decisions">
          <span class="privacy-number">03</span>
          <div><h2>Refund decisions</h2><p>Approved refunds return the buyer’s payment through the available wallet or payment workflow. Seller payouts are released only after acceptance or a resolved decision.</p></div>
        </div>
        <div class="privacy-section reveal" id="abuse">
          <span class="privacy-number">04</span>
          <div><h2>Abuse prevention</h2><p>Fraudulent proofs, harassment, chargeback abuse, and repeated bad-faith disputes may lead to account restrictions or removal.</p><a class="btn btn-outline privacy-contact" href="<?= e(base_url('support.php')) ?>">Ask about an order <?= ui_icon('arrow-right', 15) ?></a></div>
        </div>
      </article>
    </div>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
