<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$me = require_user();
$uid = (int) $me['id'];
$services = rows(
    'SELECT s.*, u.full_name, u.account_status, u.premium_until, u.profile_frame, u.profile_accent
     FROM favorites f JOIN services s ON s.id = f.service_id
     JOIN users u ON u.id = s.seller_id
     WHERE f.user_id = ? ORDER BY f.id DESC',
    [$uid]
);
$pageTitle = 'Saved services';
$currentNav = 'saved';
require __DIR__ . '/includes/header.php';
?>
<section class="page-head"><div class="container"><span class="eyebrow">Your shortlist</span><h1>Saved services</h1><p class="muted">Keep promising services nearby while you decide.</p></div></section>
<section class="section-tight"><div class="container">
<?php if ($services): ?>
  <div class="grid-3">
  <?php foreach ($services as $sv): ?>
    <article class="card card-hover service-card"><div class="sv-body">
      <div class="sv-top"><span class="sv-cat"><?= cat_icon($sv['category']) ?> <?= e($sv['category']) ?></span><span class="sv-delivery"><?= (int) $sv['delivery_days'] ?> day<?= (int) $sv['delivery_days'] > 1 ? 's' : '' ?></span></div>
      <h3><a href="<?= e(base_url('service.php?id=' . (int) $sv['id'])) ?>"><?= e($sv['title']) ?></a></h3>
      <p class="sv-desc"><?= e($sv['description']) ?></p>
    </div><div class="sv-foot"><span class="sv-price"><?= price((float) $sv['price']) ?></span>
      <a class="btn btn-primary btn-sm" href="<?= e(base_url('service.php?id=' . (int) $sv['id'])) ?>">View</a>
      <form method="post" action="<?= e(base_url('service.php?id=' . (int) $sv['id'])) ?>" style="display:inline"><?= csrf_field() ?><input type="hidden" name="return" value="saved"><button class="btn btn-outline btn-sm" name="toggle_save" value="1" type="submit">Remove</button></form>
    </div></article>
  <?php endforeach; ?>
  </div>
<?php else: ?>
  <div class="card empty-state"><div class="es-ic"><?= ui_icon('star') ?></div><b>No saved services yet</b><p>Save services you like while browsing the marketplace.</p><a class="btn btn-primary" href="<?= e(base_url('browse.php')) ?>">Browse services</a></div>
<?php endif; ?>
</div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
