<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/paymongo.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

function paymongo_json_response(int $status, array $body): never
{
    http_response_code($status);
    echo json_encode($body, JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if (!PAYMONGO_ENABLED) {
    paymongo_json_response(503, ['error' => 'PayMongo QR Ph is not ready. Ask the site administrator to finish payment setup.']);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    paymongo_json_response(405, ['error' => 'Method not allowed.']);
}

$input = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($input)) {
    paymongo_json_response(400, ['error' => 'Invalid request.']);
}
$_POST['csrf'] = (string) ($input['csrf'] ?? '');
verify_csrf();
$me = require_user();
$userId = (int) $me['id'];
$action = (string) ($input['action'] ?? '');

try {
    if ($action === 'create') {
        if (!throttle_allows('paymongo-create:' . $userId, 8, 3600)) {
            paymongo_json_response(429, ['error' => 'Too many payment attempts. Please wait and try again.']);
        }
        $purpose = (string) ($input['purpose'] ?? '');
        $orderId = filter_var($input['order_id'] ?? 0, FILTER_VALIDATE_INT);
        $amount = clean_price((string) ($input['amount'] ?? '0'));
        $checkout = paymongo_create_checkout($userId, $purpose, $orderId === false ? 0 : (int) $orderId, $amount);
        paymongo_json_response(201, ['checkout' => $checkout]);
    }

    $checkoutId = filter_var($input['checkout_id'] ?? 0, FILTER_VALIDATE_INT);
    if ($checkoutId === false || $checkoutId < 1) {
        paymongo_json_response(400, ['error' => 'Invalid checkout.']);
    }
    $checkout = row(
        'SELECT * FROM paymongo_checkouts WHERE id = ? AND user_id = ?',
        [(int) $checkoutId, $userId]
    );
    if (!$checkout) {
        paymongo_json_response(404, ['error' => 'Checkout not found.']);
    }

    if ($action === 'attach') {
        paymongo_save_qr(
            $userId,
            (int) $checkoutId,
            (string) ($input['payment_intent_id'] ?? ''),
            (string) ($input['qr_image'] ?? '')
        );
        paymongo_json_response(200, ['ok' => true]);
    }

    if ($action === 'status') {
        if ($checkout['status'] === 'pending' && strtotime((string) $checkout['created_at']) <= time() - 1800) {
            q("UPDATE paymongo_checkouts SET status = 'expired' WHERE id = ? AND status = 'pending'", [(int) $checkoutId]);
            paymongo_json_response(200, ['status' => 'expired', 'paid_at' => null]);
        }
        if ($checkout['status'] === 'pending' && !empty($checkout['payment_intent_id'])) {
            $intent = paymongo_fetch_intent((string) $checkout['payment_intent_id']);
            $status = (string) ($intent['data']['attributes']['status'] ?? '');
            if ($status === 'succeeded') {
                paymongo_apply_paid_intent((string) $checkout['payment_intent_id'], $intent);
                $checkout = row('SELECT status, paid_at FROM paymongo_checkouts WHERE id = ?', [(int) $checkoutId]);
            } elseif (($intent['data']['attributes']['last_payment_error'] ?? null) !== null) {
                q("UPDATE paymongo_checkouts SET status = 'failed' WHERE id = ? AND status = 'pending'", [(int) $checkoutId]);
                $checkout['status'] = 'failed';
            }
        }
        paymongo_json_response(200, [
            'status' => (string) $checkout['status'],
            'paid_at' => $checkout['paid_at'] ?? null,
        ]);
    }

    paymongo_json_response(400, ['error' => 'Unknown payment action.']);
} catch (InvalidArgumentException $e) {
    paymongo_json_response(422, ['error' => $e->getMessage()]);
} catch (Throwable $e) {
    error_log('PayMongo checkout error: ' . $e->getMessage());
    paymongo_json_response(502, [
        'error' => $e instanceof PDOException
            ? 'A server error prevented this payment. Please try again or contact support.'
            : $e->getMessage(),
    ]);
}
