<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';

$me = get_user();
$config = [
    'homeUrl' => base_url('index.php'),
    'browseUrl' => base_url('browse.php'),
    'careersUrl' => HIRING_SITE_URL,
    'aboutUrl' => base_url('about.php'),
    'guideUrl' => base_url('guide.php'),
    'termsUrl' => base_url('terms.php'),
    'privacyUrl' => base_url('privacy.php'),
    'logoUrl' => base_url('assets/nerasky-logo.png'),
    'authUrl' => base_url($me ? 'sell.php' : 'register.php'),
    'authLabel' => $me ? 'Post a service' : 'Join free',
    'dashboardUrl' => base_url('index.php'),
    'dashboardLabel' => 'Visit Nerasky',
];
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Make your next move count · Nerasky</title>
    <meta name="description" content="Find trusted student services for your next project, or turn the skills you already have into paid opportunities.">
    <meta property="og:title" content="Make your next move count · Nerasky">
    <meta property="og:description" content="Find trusted student services for your next project, or turn the skills you already have into paid opportunities.">
    <meta property="og:type" content="website">
    <link rel="icon" type="image/png" href="<?= e(base_url('assets/nerasky-logo.png')) ?>">
    <link rel="apple-touch-icon" href="<?= e(base_url('assets/nerasky-logo.png')) ?>">
    <link rel="stylesheet" href="<?= e(base_url('assets/landing.css?v=' . (is_file(__DIR__ . '/assets/landing.css') ? filemtime(__DIR__ . '/assets/landing.css') : '1'))) ?>">
    <link rel="stylesheet" href="<?= e(base_url('assets/landing-effects.css?v=' . (is_file(__DIR__ . '/assets/landing-effects.css') ? filemtime(__DIR__ . '/assets/landing-effects.css') : '1'))) ?>">
  </head>
  <body>
    <div id="root"></div>
    <script>window.NERASKY_CONFIG = <?= json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
    <script src="<?= e(base_url('assets/landing.js?v=' . (is_file(__DIR__ . '/assets/landing.js') ? filemtime(__DIR__ . '/assets/landing.js') : '1'))) ?>" defer></script>
  </body>
</html>
